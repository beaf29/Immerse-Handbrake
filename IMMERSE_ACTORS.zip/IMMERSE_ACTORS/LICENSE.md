Immerse Handbrake License

Copyright © 2026 Immerse Solutions. All rights reserved.

You may download Immerse Handbrake for free and install, configure, and run it on one FiveM server you own or operate. This includes delivering the resource to connected players as part of normal FiveM gameplay.

You must obtain written permission from Immerse Solutions before redistributing, reuploading, selling, or bundling the resource, including modified copies. The same requirement applies to extracting its original code or sounds for use in another resource. Keep this license and the original copyright notices with your copy. Any third-party materials remain subject to their respective licenses.

You are welcome to share the official download link. For downloads or permission requests, visit the https://discord.gg/m7kfqmM6hh
