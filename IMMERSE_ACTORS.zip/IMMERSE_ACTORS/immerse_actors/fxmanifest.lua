fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Immerse Solutions'
description 'Immerse Actors - cinematic actors, RPEmotes, freecam and Crowd Builder'
version '1.0.1'

ui_page 'ui/index.html'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

files {
  'ui/index.html',
  'ui/style.css',
  'ui/app.js',
  'emotes.json'
}
