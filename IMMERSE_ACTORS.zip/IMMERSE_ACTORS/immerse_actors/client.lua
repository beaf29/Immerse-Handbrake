local actors, nextId = {}, 1
-- Crowds are scene-local containers of regular, individually editable actors.
local groups, nextGroupId = {}, 1
local groupMoveState, creatingCrowd = nil, false
local stopGroupMove = function() end
local menuOpen, editorOpen, freecam = false, false, false
local activeCam = 0
local cameraPosition, cameraRotation, cameraFov
local hoveredId, selectedId = nil, nil
local movingId, moveHeight, moveHeading = nil, 0.0, 0.0
local statusText = 'Checking for RPEmotes...'
local lastHoverSync, requestSerial = false, 0
local pendingEmotes = {}
local cameraHoverProbe = nil
local cameraHoverBlockDistance = nil

local function clamp(x, low, high) return math.max(low, math.min(high, x)) end
local function exists(entity) return entity and entity ~= 0 and DoesEntityExist(entity) end

local function notify(message, level)
  SendNUIMessage({ type = 'toast', text = tostring(message), level = level or 'info' })
end

local function actorById(id)
  return actors[tonumber(id)]
end

local function actorList()
  local result = {}
  for id, actor in pairs(actors) do
    if exists(actor.ped) then
      result[#result + 1] = {
        id = id, label = actor.label, frozen = actor.frozen,
        weapon = actor.weapon or 'none', emote = actor.emote or 'None',
        behavior = actor.behavior or 'idle', emoteLoop = actor.emoteLoop == true, groupId = actor.groupId
      }
    end
  end
  table.sort(result, function(a, b) return a.id < b.id end)
  return result
end

local function groupList()
  local list = {}
  for id, group in pairs(groups) do
    local live = 0
    for _, actorId in ipairs(group.ids) do
      if actors[actorId] and exists(actors[actorId].ped) then live = live + 1 end
    end
    if live > 0 then
      list[#list+1] = { id=id, name=group.label, preset=group.preset,
        count=live, mood=group.mood, formation=group.formation }
    end
  end
  table.sort(list, function(a,b) return a.id > b.id end)
  return list
end

local function pushGroups()
  SendNUIMessage({type='groups', groups=groupList()})
end

local function pushActors()
  SendNUIMessage({ type = 'actors', actors = actorList(), selectedId = selectedId })
end

local function pushDetails()
  local actor = selectedId and actorById(selectedId) or nil
  if actor then
    SendNUIMessage({ type = 'actorDetail', actor = {
      id = selectedId, label = actor.label, frozen = actor.frozen,
      weapon = actor.weapon or 'none', emote = actor.emote or 'None',
      behavior = actor.behavior or 'idle', emoteLoop = actor.emoteLoop == true, groupId = actor.groupId
    }})
  else
    SendNUIMessage({ type = 'actorDetail', actor = nil })
  end
end

local function cleanupProps(actor)
  if not actor then return end
  if actor.props then
    for _, object in ipairs(actor.props) do
      if exists(object) then
        SetEntityAsMissionEntity(object, true, true)
        DeleteEntity(object)
      end
    end
  end
  actor.props = {}
end

local function clearEmote(actor)
  if not actor or not exists(actor.ped) then return end
  cleanupProps(actor)
  ClearPedTasksImmediately(actor.ped)
  actor.emote = 'None'
  actor.emoteInfo = nil
end

-- Action modes deliberately replace previous emotes/AI tasks.
-- Actors remain client-local (unless the experimental network option is enabled).
local function holdActor(actor)
  if not actor or not exists(actor.ped) then return end
  clearEmote(actor)
  actor.behavior = 'idle'
  actor.leaveTarget = nil
  SetBlockingOfNonTemporaryEvents(actor.ped, true)
  SetPedCanRagdoll(actor.ped, false)
  SetEntityInvincible(actor.ped, true)
  SetPedKeepTask(actor.ped, false)
  actor.frozen = true
  FreezeEntityPosition(actor.ped, true)
end

local function startBehavior(actor, behavior)
  if not actor or not exists(actor.ped) then return false end
  if behavior == 'stop' then
    holdActor(actor)
    notify('Actor stopped and held in position.', 'success')
    pushActors(); pushDetails()
    return true
  end
  if behavior ~= 'follow' and behavior ~= 'fight' and behavior ~= 'leave' then return false end
  local ped, playerPed = actor.ped, PlayerPedId()
  if not exists(playerPed) then return false end
  clearEmote(actor)
  actor.behavior = behavior
  actor.leaveTarget = nil
  actor.frozen = false
  SetEntityCollision(ped, true, true)
  FreezeEntityPosition(ped, false)
  SetPedCanRagdoll(ped, true)
  SetPedKeepTask(ped, true)
  if behavior == 'follow' then
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedAlertness(ped, 0)
    TaskFollowToOffsetOfEntity(ped, playerPed, 0.0, -1.7, 0.0,
      Config.FollowSpeed or 1.5, -1, 1.8, true)
    notify('Actor is following you. F9 to return to camera.', 'success')
  elseif behavior == 'fight' then
    SetEntityInvincible(ped, false)
    SetBlockingOfNonTemporaryEvents(ped, false)
    SetPedCombatAbility(ped, 1)
    SetPedCombatMovement(ped, 2)
    SetPedCombatRange(ped, 1)
    TaskCombatPed(ped, playerPed, 0, 16)
    notify('Actor is attacking you.', 'success')
  elseif behavior == 'leave' then
    SetEntityInvincible(ped, false)
    SetBlockingOfNonTemporaryEvents(ped, false)
    local here, playerPos = GetEntityCoords(ped), GetEntityCoords(playerPed)
    local away = vector3(here.x - playerPos.x, here.y - playerPos.y, 0.0)
    if #away < 0.5 then
      away = GetEntityForwardVector(ped)
      away = vector3(away.x, away.y, 0.0)
    end
    local magnitude = math.max(#away, 0.001)
    away = away / magnitude
    local distance = Config.LeaveAreaDistance or 25.0
    local wanted = here + away * distance
    local onGround, groundZ = GetGroundZFor_3dCoord(wanted.x, wanted.y, wanted.z + 12.0, false)
    local target = vector3(wanted.x, wanted.y, onGround and groundZ or here.z)
    actor.leaveTarget = target
    actor.leaveStart = GetGameTimer()
    TaskFollowNavMeshToCoord(ped, target.x, target.y, target.z,
      Config.LeaveWalkSpeed or 1.05, 28000, 1.2, false, 0.0)
    notify('Actor is leaving the scene and will begin wandering.', 'success')
  end
  pushActors(); pushDetails()
  return true
end

-- Finish 'Leave Area' by handing the ped back to GTA's ambient wandering AI.
CreateThread(function()
  while true do
    Wait(1250)
    for _, actor in pairs(actors) do
      if actor.behavior == 'leave' and actor.leaveTarget and exists(actor.ped) then
        local elapsed = GetGameTimer() - (actor.leaveStart or GetGameTimer())
        local distance = #(GetEntityCoords(actor.ped) - actor.leaveTarget)
        if distance < 3.5 or elapsed > 28000 then
          actor.behavior = 'ambient'
          actor.leaveTarget = nil
          SetBlockingOfNonTemporaryEvents(actor.ped, false)
          TaskWanderStandard(actor.ped, 10.0, 10)
          SetPedKeepTask(actor.ped, true)
          pushActors(); pushDetails()
        end
      end
    end
  end
end)

local function cleanWeapon(actor)
  if not actor or not exists(actor.ped) then return end
  RemoveAllPedWeapons(actor.ped, true)
  actor.weapon = 'none'
end

local function setWeapon(actor, weaponName)
  if not actor or not exists(actor.ped) then return end
  local allowed = false
  for _, option in ipairs(Config.Weapons) do
    if option.name == weaponName then allowed = true; break end
  end
  if not allowed then notify('That weapon is not in the allowed list.', 'error'); return end
  cleanWeapon(actor)
  if weaponName ~= 'none' then
    local hash = GetHashKey(weaponName)
    GiveWeaponToPed(actor.ped, hash, 120, false, true)
    SetCurrentPedWeapon(actor.ped, hash, true)
    actor.weapon = weaponName
  end
  pushActors()
  pushDetails()
end

local function deleteActor(id, quiet)
  local actor = actorById(id)
  if not actor then return end
  cleanupProps(actor)
  if exists(actor.ped) then
    SetEntityAsMissionEntity(actor.ped, true, true)
    DeleteEntity(actor.ped)
  end
  if actor.groupId and groups[actor.groupId] then
    local group = groups[actor.groupId]
    group.offsets=nil -- compact formation after removing an individual
    for i = #group.ids, 1, -1 do
      if group.ids[i] == tonumber(id) then table.remove(group.ids, i) end
    end
    if #group.ids == 0 then groups[actor.groupId] = nil end
  end
  actors[tonumber(id)] = nil
  if selectedId == tonumber(id) then selectedId = nil end
  if hoveredId == tonumber(id) then hoveredId = nil end
  if movingId == tonumber(id) then movingId = nil end
  if not quiet then pushActors(); pushDetails(); pushGroups() end
end

local function createActor()
  local count = 0
  for _, a in pairs(actors) do if exists(a.ped) then count = count + 1 end end
  if count >= Config.MaxActors then
    notify(('Scene limit reached (%d clones).'):format(Config.MaxActors), 'error')
    return
  end
  local playerPed = PlayerPedId()
  if not exists(playerPed) or IsEntityDead(playerPed) then
    notify('You must be alive to clone your MP ped.', 'error')
    return
  end
  if IsPedInAnyVehicle(playerPed, false) then
    notify('Step out of your vehicle before cloning your ped.', 'error')
    return
  end
  local clone = ClonePed(playerPed, Config.NetworkedActors == true, false, true)
  if not exists(clone) then
    notify('The game did not create a clone. Try again.', 'error')
    return
  end
  SetEntityAsMissionEntity(clone, true, true)
  local spawn = GetOffsetFromEntityInWorldCoords(playerPed, 0.0, 2.4, 0.0)
  -- SetEntityCoords uses a GROUND-level Z for peds and applies their foot/origin offset.
  -- The old SetEntityCoordsNoOffset put the clone's torso into the terrain.
  local playerMin = GetModelDimensions(GetEntityModel(playerPed))
  local fallbackGround = GetEntityCoords(playerPed).z + math.min(playerMin.z, 0.0)
  local groundFound, groundZ = GetGroundZFor_3dCoord(spawn.x, spawn.y, spawn.z + 5.0, false)
  SetEntityCoords(clone, spawn.x, spawn.y,
    (groundFound and groundZ or fallbackGround) + (Config.PlacementLift or 0.02), false, false, false, false)
  SetEntityHeading(clone, GetEntityHeading(playerPed) + 180.0)
  SetPedCanRagdoll(clone, false)
  SetEntityInvincible(clone, true)
  SetBlockingOfNonTemporaryEvents(clone, true)
  SetPedFleeAttributes(clone, 0, false)
  SetPedCombatAttributes(clone, 17, true)
  ClearPedTasksImmediately(clone)
  RemoveAllPedWeapons(clone, true)
  SetEntityCollision(clone, true, true)
  FreezeEntityPosition(clone, true)
  local id = nextId
  nextId = nextId + 1
  actors[id] = { ped = clone, label = 'Clone ' .. id, frozen = true,
    weapon = 'none', emote = 'None', emoteInfo = nil,
    emoteLoop = Config.EmoteLoopDefault == true, props = {}, behavior = 'idle' }
  selectedId = id
  pushActors()
  pushDetails()
  notify('MP ped cloned. Press F9 for the free camera.', 'success')
end

-- Bring a managed clone to the player's character, rather than the freecam.
-- Preserve an active idle animation; reset follow/combat/wandering AI so it
-- doesn't instantly run back to its previous task/location.
local function bringActorToPlayer(id)
  local actor = actorById(id)
  local playerPed = PlayerPedId()
  if not actor or not exists(actor.ped) or not exists(playerPed) then
    notify('Actor or player no longer exists.', 'error')
    return false
  end
  if IsPedInAnyVehicle(playerPed, false) then
    notify('Exit your vehicle before bringing an actor over.', 'error')
    return false
  end
  local position = GetOffsetFromEntityInWorldCoords(playerPed, 0.8, 1.8, 0.0)
  local currentPosition = GetEntityCoords(playerPed)
  -- Interior floors may not report a ground Z. Fall back to the local player's
  -- ped-origin height on the same floor, not the map's lower terrain.
  local found, groundZ = GetGroundZFor_3dCoord(position.x, position.y, position.z + 4.0, false)
  local playerFeet = currentPosition.z + (select(1, GetModelDimensions(GetEntityModel(playerPed)))).z
  local useGround = found and math.abs(groundZ - playerFeet) < 1.6

  local ped = actor.ped
  actor.leaveTarget = nil
  if actor.behavior ~= 'idle' then
    holdActor(actor)
  end
  actor.behavior = 'idle'
  SetBlockingOfNonTemporaryEvents(ped, true)
  SetEntityInvincible(ped, true)
  SetPedCanRagdoll(ped, false)
  SetPedKeepTask(ped, false)
  SetEntityCollision(ped, true, true)
  FreezeEntityPosition(ped, true)
  if useGround then
    SetEntityCoords(ped, position.x, position.y, groundZ + (Config.PlacementLift or 0.02), false, false, false, false)
  else
    SetEntityCoordsNoOffset(ped, position.x, position.y, currentPosition.z, false, false, false)
  end
  SetEntityHeading(ped, (GetEntityHeading(playerPed) + 180.0) % 360.0)
  actor.frozen = true
  if movingId == tonumber(id) then
    movingId = nil
    actor.moveOrigin = nil
    SendNUIMessage({ type = 'moving', active = false })
  end
  pushActors()
  pushDetails()
  notify(actor.label .. ' brought to your position.', 'success')
  return true
end

local function stopFocus()
  SetNuiFocusKeepInput(false)
  SetNuiFocus(false, false)
end

local function stopEditor()
  editorOpen = false
  stopFocus()
  SendNUIMessage({ type = 'editor', show = false })
end

local function closeMenu()
  menuOpen = false
  stopFocus()
  SendNUIMessage({ type = 'menu', show = false })
end

local function stopMove(commit)
  if not movingId then return end
  local actor = actorById(movingId)
  if actor and exists(actor.ped) then
    ResetEntityAlpha(actor.ped)
    if not commit and actor.moveOrigin then
      -- moveOrigin stores the actual ped origin coordinate, not a ground-level Z.
      SetEntityCoordsNoOffset(actor.ped, actor.moveOrigin.x, actor.moveOrigin.y, actor.moveOrigin.z, false, false, false)
      SetEntityHeading(actor.ped, actor.moveOrigin.h)
    end
    FreezeEntityPosition(actor.ped, actor.frozen)
    actor.moveOrigin = nil
  end
  movingId = nil
  SendNUIMessage({ type = 'moving', active = false })
  pushActors()
end

local function exitCamera()
  if editorOpen then stopEditor() end
  if movingId then stopMove(false) end
  if groupMoveState then stopGroupMove(false) end
  cameraHoverProbe = nil
  cameraHoverBlockDistance = nil
  freecam = false
  hoveredId = nil
  selectedId = nil
  if activeCam ~= 0 then
    RenderScriptCams(false, true, 200, true, true)
    DestroyCam(activeCam, false)
    activeCam = 0
  end
  ClearFocus()
  stopFocus()
  SendNUIMessage({ type = 'camera', show = false })
  pushDetails()
end

local function enterCamera()
  if freecam then return end
  if menuOpen then closeMenu() end
  if editorOpen then stopEditor() end
  cameraPosition = GetGameplayCamCoord()
  cameraRotation = GetGameplayCamRot(2)
  cameraFov = Config.DefaultFov
  activeCam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
  SetCamCoord(activeCam, cameraPosition.x, cameraPosition.y, cameraPosition.z)
  SetCamRot(activeCam, cameraRotation.x, cameraRotation.y, cameraRotation.z, 2)
  SetCamFov(activeCam, cameraFov)
  SetCamActive(activeCam, true)
  RenderScriptCams(true, true, 200, true, true)
  freecam = true
  cameraHoverProbe = nil
  cameraHoverBlockDistance = nil
  hoveredId = nil
  SendNUIMessage({ type = 'camera', show = true })
end

local function showMenu()
  if freecam then exitCamera() end
  if menuOpen then return end
  menuOpen = true
  SetNuiFocus(true, true)
  SendNUIMessage({ type = 'menu', show = true, actors = actorList(),
    maxActors = Config.MaxActors, weapons = Config.Weapons, source = statusText,
    groups = groupList(), presets = Config.CrowdPresets, moods = Config.CrowdMoods,
    formations = Config.CrowdFormations, maxCrowdSize = Config.MaxCrowdSize })
  TriggerServerEvent('immerse_actors:requestStatus')
end

local function showEditor(id)
  local actor = actorById(id)
  if not freecam or not actor or not exists(actor.ped) then return end
  if movingId then stopMove(false) end
  if groupMoveState then stopGroupMove(false) end
  cameraHoverProbe = nil
  cameraHoverBlockDistance = nil
  selectedId = tonumber(id)
  editorOpen = true
  SetNuiFocus(true, true)
  SetNuiFocusKeepInput(false)
  SendNUIMessage({ type = 'editor', show = true, weapons = Config.Weapons, source = statusText })
  pushDetails()
end

local function moveActor(id)
  local actor = actorById(id)
  if not freecam or not actor or not exists(actor.ped) then return end
  if editorOpen then stopEditor() end
  holdActor(actor)
  movingId = tonumber(id)
  moveHeight = 0.0
  moveHeading = GetEntityHeading(actor.ped)
  local pos = GetEntityCoords(actor.ped)
  actor.moveOrigin = {x = pos.x, y = pos.y, z = pos.z, h = moveHeading}
  actor.lastMovePoint = nil
  actor.lastMoveValid = false
  SetEntityAlpha(actor.ped, 175, false)
  FreezeEntityPosition(actor.ped, true)
  SendNUIMessage({ type = 'moving', active = true })
  notify('Aim to place · Click to confirm · Right-click to cancel')
end

local function vectorDot(a, b) return a.x*b.x + a.y*b.y + a.z*b.z end
local function getDirection(rotation)
  local pitch, yaw = math.rad(rotation.x), math.rad(rotation.z)
  return vector3(-math.sin(yaw)*math.cos(pitch), math.cos(yaw)*math.cos(pitch), math.sin(pitch))
end

-- Small, actual body-sized capsules following the NPC's animated skeleton.
-- This fixes the old center+0.95 targeting bias (which targeted empty air above a buried ped).
local function distanceToBoneSegment(from, direction, first, last)
  local axis = last - first
  local fromFirst = from - first
  local b, c = vectorDot(direction, axis), vectorDot(axis, axis)
  local d, e = vectorDot(direction, fromFirst), vectorDot(axis, fromFirst)
  local denominator = c - b*b
  local t, s
  if denominator > 0.0001 then
    t = math.max(0.0, (b*e-c*d)/denominator)
    s = clamp((e+b*t)/c, 0.0, 1.0)
  else
    s = clamp(e / math.max(c, 0.0001), 0.0, 1.0)
  end
  t = math.max(0.0, vectorDot(first + axis*s - from, direction))
  local hitPoint = from + direction*t
  local bonePoint = first + axis*s
  return #(hitPoint-bonePoint), t
end

local function pickActor(position, direction, blockedAt)
  local nearestId, nearestDepth = nil, Config.MaximumCameraRange + 1.0
  for id, actor in pairs(actors) do
    local ped = actor.ped
    if exists(ped) and not IsEntityDead(ped) then
      -- Cheap cull: the torso must be somewhere near the exact center camera ray.
      local torso = GetPedBoneCoords(ped, 24816, 0.0, 0.0, 0.0)
      local ahead = vectorDot(torso-position, direction)
      if ahead > 0.05 and ahead < nearestDepth + 2.0 and ahead < Config.MaximumCameraRange then
        local nearest = position + direction*ahead
        if #(torso-nearest) < 2.2 then
          local head = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0)
          local pelvis = GetPedBoneCoords(ped, 11816, 0.0, 0.0, 0.0)
          local lHand = GetPedBoneCoords(ped, 18905, 0.0, 0.0, 0.0)
          local rHand = GetPedBoneCoords(ped, 57005, 0.0, 0.0, 0.0)
          local lArm = GetPedBoneCoords(ped, 45509, 0.0, 0.0, 0.0)
          local rArm = GetPedBoneCoords(ped, 40269, 0.0, 0.0, 0.0)
          local lFoot = GetPedBoneCoords(ped, 14201, 0.0, 0.0, 0.0)
          local rFoot = GetPedBoneCoords(ped, 52301, 0.0, 0.0, 0.0)
          local parts = {
            {head, head + vector3(0,0,0.1), .17},
            {head, torso, .24},
            {torso, pelvis, .31},
            {torso, lArm, .22}, {lArm, lHand, .16},
            {torso, rArm, .22}, {rArm, rHand, .16},
            {pelvis, lFoot, .21}, {pelvis, rFoot, .21}
          }
          for _, part in ipairs(parts) do
            local width, distance = distanceToBoneSegment(position, direction, part[1], part[2])
            if width <= part[3] and distance < nearestDepth and (not blockedAt or distance < blockedAt + 0.85) then
              nearestId, nearestDepth = id, distance
            end
          end
        end
      end
    end
  end
  return nearestId
end

-- Probing the real center ray also rejects walls in front of a clone. Mission peds
-- are sometimes not reported at long range, which is why bone capsules are retained.
local function updateCameraOcclusion(position, direction)
  if cameraHoverProbe then
    local state, didHit, hitCoords = GetShapeTestResult(cameraHoverProbe)
    if state == 2 then
      cameraHoverBlockDistance = (didHit == true or didHit == 1) and #(hitCoords-position) or nil
      cameraHoverProbe = nil
    elseif state == 0 then
      cameraHoverProbe = nil
      cameraHoverBlockDistance = nil
    end
  end
  if not cameraHoverProbe then
    local far = position + direction * Config.MaximumCameraRange
    cameraHoverProbe = StartShapeTestLosProbe(position.x, position.y, position.z,
      far.x, far.y, far.z, 1+2+4+16, PlayerPedId(), 7)
  end
  return cameraHoverBlockDistance
end

local function applyEmote(actor, info, code, quiet)
  if not actor or not exists(actor.ped) then return end
  if type(info) ~= 'table' then return end
  holdActor(actor)
  if info.kind == 'scenario' then
    local scenario = tostring(info.scenario or '')
    if scenario == '' then notify('The scenario definition was incomplete.', 'error'); return end
    TaskStartScenarioInPlace(actor.ped, scenario, 0, true)
  elseif info.kind == 'anim' then
    local dict, clip = tostring(info.dict or ''), tostring(info.clip or '')
    if dict == '' or clip == '' then notify('This emote has no animation dictionary or clip.', 'error'); return end
    RequestAnimDict(dict)
    local deadline = GetGameTimer() + 4000
    while not HasAnimDictLoaded(dict) and GetGameTimer() < deadline do Wait(0) end
    if not HasAnimDictLoaded(dict) then
      notify(('Animation "%s" could not load. Check streamed animations.'):format(code), 'error')
      return
    end
    local flag = actor.emoteLoop and 1 or 0
    if info.moving then flag = flag + 48 end
    -- Override finite RPEmotes durations while locked in a continuous loop.
    local duration = actor.emoteLoop and -1 or (tonumber(info.duration) or -1)
    TaskPlayAnim(actor.ped, dict, clip, 3.0, 3.0, duration, flag, 0.0, false, false, false)
    RemoveAnimDict(dict)
    if type(info.props) == 'table' then
      for _, propInfo in ipairs(info.props) do
        local model = tostring(propInfo.model or '')
        local hash = GetHashKey(model)
        if model ~= '' and IsModelInCdimage(hash) and IsModelValid(hash) then
          RequestModel(hash)
          local limit = GetGameTimer() + 2500
          while not HasModelLoaded(hash) and GetGameTimer() < limit do Wait(0) end
          if HasModelLoaded(hash) then
            local pos = GetEntityCoords(actor.ped)
            local obj = CreateObject(hash, pos.x, pos.y, pos.z, Config.NetworkedActors == true, false, false)
            if exists(obj) then
              local p = propInfo.placement or {0,0,0,0,0,0}
              AttachEntityToEntity(obj, actor.ped, GetPedBoneIndex(actor.ped, tonumber(propInfo.bone) or 28422),
                tonumber(p[1]) or 0.0, tonumber(p[2]) or 0.0, tonumber(p[3]) or 0.0,
                tonumber(p[4]) or 0.0, tonumber(p[5]) or 0.0, tonumber(p[6]) or 0.0,
                true, true, false, true, 1, true)
              actor.props[#actor.props+1] = obj
            end
            SetModelAsNoLongerNeeded(hash)
          end
        end
      end
    end
  else
    notify('Unsupported emote type.', 'error')
    return
  end
  actor.emote = code
  actor.emoteInfo = info -- Retain the definition for re-looping without a server lookup.
  if not quiet then
    pushActors()
    pushDetails()
    notify('Playing emote: ' .. code .. (actor.emoteLoop and ' (continuous loop)' or ''), 'success')
  end
end


-- ========================== CROWD BUILDER ================================
-- Controlled GTA ambient-ped populations, kept separate from player clones.
local function activeActorCount()
  local n = 0
  for _, a in pairs(actors) do if exists(a.ped) then n=n+1 end end
  return n
end

local function randomFloat(a, b)
  return a + (b-a) * math.random()
end

local function makeCrowdOffsets(count, formation, spacing)
  local offsets = {}
  if formation == 'line' then
    local columns = math.min(10, math.max(4, math.ceil(math.sqrt(count)*1.7)))
    local rows = math.ceil(count / columns)
    for i=1,count do
      local row = math.floor((i-1)/columns)
      local col = (i-1)%columns
      local inRow = math.min(columns, count-row*columns)
      offsets[i] = {x=(col-(inRow-1)/2)*spacing, y=(row-(rows-1)/2)*spacing*0.85}
    end
  elseif formation == 'arc' then
    for i=1,count do
      local ring = math.floor((i-1)/10)
      local position = (i-1)%10
      local ringSize = math.min(10, count-ring*10)
      local angle = math.rad(-84 + (ringSize == 1 and 84 or position*168/(ringSize-1)))
      local radius = 1.5 + (ring+1)*spacing*1.3
      offsets[i] = {x=math.sin(angle)*radius, y=math.cos(angle)*radius - 2.4}
    end
  else -- scatter / mixed crowd
    local columns = math.ceil(math.sqrt(count*1.25))
    local rows = math.ceil(count/columns)
    for i=1,count do
      local row = math.floor((i-1)/columns)
      local col = (i-1)%columns
      offsets[i] = {x=(col-(columns-1)/2)*spacing + randomFloat(-.42,.42)*spacing,
                    y=(row-(rows-1)/2)*spacing + randomFloat(-.35,.35)*spacing}
    end
  end
  return offsets
end

local function rotate2d(x,y,heading)
  local theta = math.rad(heading)
  -- GTA heading zero faces +Y, positive heading turns toward -X.
  return x*math.cos(theta)-y*math.sin(theta),
         x*math.sin(theta)+y*math.cos(theta)
end

local function crowdGround(x,y,proposedZ)
  local found, z = GetGroundZFor_3dCoord(x,y, proposedZ+25.0, false)
  -- GroundZ can refer to terrain *under* an interior/roof. Preserve camera-ray level.
  if found and math.abs(z-proposedZ) < 1.35 then return z end
  return proposedZ
end

local function placeGroupAt(group, anchor, heading, spacing, adjustZ)
  if not group then return end
  group.anchor, group.heading, group.spacing = anchor, heading, spacing
  -- Generate stable per-member offsets once. Never rerandomize while dragging.
  if not group.offsets then group.offsets=makeCrowdOffsets(#group.ids, group.formation, 1.0) end
  local offsets = group.offsets
  for i,id in ipairs(group.ids) do
    local actor = actorById(id)
    if actor and exists(actor.ped) then
      local off = offsets[i]
      local dx,dy = rotate2d(off.x*spacing,off.y*spacing,heading)
      local x,y = anchor.x+dx,anchor.y+dy
      local z = crowdGround(x,y,anchor.z) + (adjustZ or 0.0)
      SetEntityCoords(actor.ped,x,y,z+(Config.PlacementLift or 0.02),false,false,false,false)
      SetEntityHeading(actor.ped,(heading+(actor.crowdHeadingOffset or 0))%360)
    end
  end
end

local function requestGroupEmotes(group)
  if not group or not groups[group.id] then return end
  local mood = Config.CrowdMoods[group.mood] or Config.CrowdMoods.carmeet
  if not mood or type(mood.emotes) ~= 'table' then return end
  local codes = {}
  for _, code in ipairs(mood.emotes) do
    if code ~= 'lean' then codes[#codes + 1] = code end
  end
  codes[#codes + 1] = 'clap'
  codes[#codes + 1] = 'clap2'
  TriggerServerEvent('immerse_actors:requestCrowdEmotes', group.id, codes)
end

RegisterNetEvent('immerse_actors:crowdEmotes',function(groupId,definitions)
  local group = groups[tonumber(groupId)]
  if not group then return end
  if groupMoveState and groupMoveState.id==group.id then return end
  local mood = Config.CrowdMoods[group.mood] or Config.CrowdMoods.carmeet
  if type(definitions) ~= 'table' then return end
  local available = {}
  for _,code in ipairs((mood and mood.emotes) or {}) do
    if code == 'clap' or code == 'clap2' then
      code = definitions.clap2 and 'clap2' or 'clap'
    end
    if code ~= 'lean' and definitions[code] then
      available[#available+1] = code
    end
  end
  if #available==0 then
    notify('No matching crowd emotes found. Check RPEmotes Reborn and /sceneactorsreload.', 'error')
    return
  end
  -- Random without replacement until all choices are used, then reshuffle.
  local bag = {}
  for _, code in ipairs(available) do bag[#bag+1]=code end
  local function takeCode()
    if #bag==0 then for _, code in ipairs(available) do bag[#bag+1]=code end end
    local index=math.random(#bag)
    local code=bag[index]
    table.remove(bag,index)
    return code
  end
  for _,id in ipairs(group.ids) do
    local actor=actorById(id)
    if actor and exists(actor.ped) then
      local code=takeCode()
      actor.emoteLoop=true
      local info = definitions[code]
      applyEmote(actor, info, code, true)
      if code == 'clap2' and definitions.clap then
        if actor.emoteInfo == info then
          -- Give GTA time to enter the task before checking the actual clip.
          Wait(350)
        end
        if actorById(id) == actor and exists(actor.ped) and not (groupMoveState and groupMoveState.id == group.id)
          and actor.behavior == 'idle' and (not actor.emoteInfo or actor.emoteInfo == info) then
          local playing = actor.emoteInfo == info and (
            (info.kind == 'anim' and IsEntityPlayingAnim(actor.ped, info.dict, info.clip, 3))
            or (info.kind == 'scenario' and IsPedUsingScenario(actor.ped, info.scenario)))
          if not playing then applyEmote(actor, definitions.clap, 'clap', true) end
        end
      end
      -- Shared task state remains individually editable via right-click.
    end
  end
  pushActors(); pushDetails(); pushGroups()
  notify(('%d actors assigned varied %s poses.'):format(#group.ids,group.mood),'success')
end)

local function createCrowd(presetKey,count,formation,spacing,moodKey)
  if creatingCrowd then notify('Another crowd is being created.', 'error'); return end
  local preset=Config.CrowdPresets[presetKey]
  if not preset then notify('Choose a crowd type.', 'error'); return end
  count=math.floor(tonumber(count) or 10)
  count=clamp(count,Config.MinCrowdSize or 3,Config.MaxCrowdSize or 30)
  formation=Config.CrowdFormations[formation] and formation or 'scatter'
  moodKey=Config.CrowdMoods[moodKey] and moodKey or 'carmeet'
  spacing=clamp(tonumber(spacing) or 1.8,1.15,4.0)
  if activeActorCount()+count > Config.MaxActors then
    notify(('Not enough actor slots. Free %d slots first.'):format(activeActorCount()+count-Config.MaxActors),'error');return
  end
  local numberOfGroups=0
  for _ in pairs(groups) do numberOfGroups=numberOfGroups+1 end
  if numberOfGroups >= (Config.MaxCrowds or 6) then
    notify('Maximum number of crowd groups reached.', 'error');return
  end
  local player=PlayerPedId()
  if not exists(player) or IsEntityDead(player) or IsPedInAnyVehicle(player,false) then
    notify('Stand on foot before creating a crowd.', 'error');return
  end
  creatingCrowd=true
  if menuOpen then closeMenu() end
  local groupId=nextGroupId;nextGroupId=nextGroupId+1
  local group={id=groupId,label=preset.label..' '..groupId,preset=presetKey,
    ids={},formation=formation,spacing=spacing,mood=moodKey,
    heading=GetEntityHeading(player),anchor=GetOffsetFromEntityInWorldCoords(player,0,7.0,0)}
  local modelPool=preset.models or {}
  local validModels={}
  for _,name in ipairs(modelPool) do
    local hash=GetHashKey(name)
    if IsModelInCdimage(hash) and IsModelValid(hash) and IsModelAPed(hash) then
      validModels[#validModels+1]={hash=hash,name=name}
    end
  end
  if #validModels==0 then creatingCrowd=false;notify('No valid ped models for this crowd.', 'error');return end
  local shuffled={}
  for _,model in ipairs(validModels) do shuffled[#shuffled+1]=model end
  for i=#shuffled,2,-1 do
    local j=math.random(i);shuffled[i],shuffled[j]=shuffled[j],shuffled[i]
  end
  local spawned=0
  for i=1,count do
    local model=shuffled[((i-1)%#shuffled)+1]
    RequestModel(model.hash)
    local deadline=GetGameTimer()+3500
    while not HasModelLoaded(model.hash) and GetGameTimer()<deadline do Wait(0) end
    if HasModelLoaded(model.hash) then
      local id=nextId;nextId=nextId+1
      local ped=CreatePed(4,model.hash,group.anchor.x,group.anchor.y,group.anchor.z,
        group.heading,Config.NetworkedActors==true,true)
      if exists(ped) then
        SetEntityAsMissionEntity(ped,true,true)
        SetPedDefaultComponentVariation(ped)
        SetPedRandomComponentVariation(ped,true)
        SetEntityInvincible(ped,true)
        SetPedCanRagdoll(ped,false)
        SetBlockingOfNonTemporaryEvents(ped,true)
        SetPedFleeAttributes(ped,0,false)
        SetEntityCollision(ped,true,true)
        RemoveAllPedWeapons(ped,true)
        ClearPedTasksImmediately(ped)
        FreezeEntityPosition(ped,true)
        local headingOffset=math.random(-22,22)
        actors[id]={ped=ped,label=preset.label..' '..(spawned+1),frozen=true,
          weapon='none',emote='None',emoteInfo=nil,emoteLoop=true,
          props={},behavior='idle',groupId=groupId,crowdHeadingOffset=headingOffset}
        group.ids[#group.ids+1]=id
        spawned=spawned+1
      end
      SetModelAsNoLongerNeeded(model.hash)
    end
    if i%4==0 then Wait(0) end
  end
  if spawned==0 then creatingCrowd=false; notify('Could not create crowd peds.','error');return end
  group.awaitingFirstPlacement=true
  groups[groupId]=group
  placeGroupAt(group,group.anchor,group.heading,spacing,0.0)
  creatingCrowd=false
  pushActors();pushGroups()
  notify(('Created %d %s. Set their position in freecam.'):format(spawned,preset.label),'success')
  -- Enter group placement directly, so the whole crowd moves together.
  if not freecam then enterCamera() end
  if freecam then
    groupMoveState={id=groupId, originalAnchor=group.anchor,
      originalHeading=group.heading, originalSpacing=group.spacing, originalPositions={},
      anchor=group.anchor, heading=group.heading,spacing=spacing,height=0.0,
      point=nil,valid=false, ray=nil, groundTick=0}
    for _,id in ipairs(group.ids) do
      local actor=actorById(id)
      if actor and exists(actor.ped) then
        groupMoveState.originalPositions[id]={position=GetEntityCoords(actor.ped),heading=GetEntityHeading(actor.ped)}
        SetEntityAlpha(actor.ped,190,false)
      end
    end
    SendNUIMessage({type='groupMove',active=true,count=spawned,label=group.label})
  else
    requestGroupEmotes(group)
  end
end

stopGroupMove = function(commit)
  if not groupMoveState then return end
  local state=groupMoveState
  local group=groups[state.id]
  if state.ray then -- async probes are discarded on scene exit.
    state.ray=nil
  end
  if group then
    if not commit then
      group.anchor=state.originalAnchor
      group.heading=state.originalHeading
      group.spacing=state.originalSpacing
      for id,origin in pairs(state.originalPositions or {}) do
        local actor=actorById(id)
        if actor and exists(actor.ped) then
          SetEntityCoordsNoOffset(actor.ped,origin.position.x,origin.position.y,origin.position.z,false,false,false)
          SetEntityHeading(actor.ped,origin.heading)
        end
      end
    end
    for _,id in ipairs(group.ids) do
      local actor=actorById(id)
      if actor and exists(actor.ped) then
        ResetEntityAlpha(actor.ped)
        FreezeEntityPosition(actor.ped, actor.frozen)
        -- Scenario tasks can reset after teleporting; replay each actor's *own* emote.
        if not group.awaitingFirstPlacement and actor.behavior=='idle' and
          actor.emoteInfo and actor.emote~='None' then
          applyEmote(actor,actor.emoteInfo,actor.emote,true)
        end
      end
    end
    if group.awaitingFirstPlacement then group.awaitingFirstPlacement=nil; requestGroupEmotes(group) end
  end
  groupMoveState=nil
  SendNUIMessage({type='groupMove',active=false})
  pushGroups()
end

local function moveCrowd(id)
  local group=groups[tonumber(id)]
  if not group then notify('That crowd no longer exists.','error');return end
  if movingId then stopMove(false) end
  if groupMoveState then stopGroupMove(false) end
  if menuOpen then closeMenu() end
  if not freecam then enterCamera() end
  groupMoveState={id=group.id,originalAnchor=group.anchor,
    originalHeading=group.heading,originalSpacing=group.spacing,
    heading=group.heading,spacing=group.spacing,height=0.0,
    originalPositions={},anchor=group.anchor,point=nil,valid=false,ray=nil,groundTick=0}
  for _,actorId in ipairs(group.ids) do
    local actor=actorById(actorId)
    if actor and exists(actor.ped) then
      groupMoveState.originalPositions[actorId]={position=GetEntityCoords(actor.ped),heading=GetEntityHeading(actor.ped)}
      FreezeEntityPosition(actor.ped,true)
      SetEntityAlpha(actor.ped,190,false)
    end
  end
  SendNUIMessage({type='groupMove',active=true,count=#group.ids,label=group.label})
end

local function deleteCrowd(id)
  local group=groups[tonumber(id)]
  if not group then return end
  if groupMoveState and groupMoveState.id==tonumber(id) then stopGroupMove(false) end
  local ids={}
  for _,actorId in ipairs(group.ids) do ids[#ids+1]=actorId end
  for _,actorId in ipairs(ids) do deleteActor(actorId,true) end
  groups[tonumber(id)]=nil
  pushGroups();pushActors()
  notify('Crowd removed from the scene.','success')
end
-- ========================================================================

-- RPEmotes clips can end after a fixed duration, or other tasks can interrupt
-- them. Reissue only the current animation/scenario for actors with loop enabled.
-- Props stay attached; do not call applyEmote here or they would duplicate.
CreateThread(function()
  while true do
    Wait(math.max(350, Config.EmoteLoopCheckMs or 950))
    for _, actor in pairs(actors) do
      local ped, info = actor.ped, actor.emoteInfo
      if actor.emoteLoop and actor.behavior == 'idle' and
        info and exists(ped) and not IsEntityDead(ped) then
        if info.kind == 'scenario' and info.scenario then
          if not IsPedUsingScenario(ped, info.scenario) then
            TaskStartScenarioInPlace(ped, info.scenario, 0, true)
          end
        elseif info.kind == 'anim' and info.dict and info.clip then
          if not IsEntityPlayingAnim(ped, info.dict, info.clip, 3) then
            if not HasAnimDictLoaded(info.dict) then
              RequestAnimDict(info.dict)
              local deadline = GetGameTimer() + 1800
              while not HasAnimDictLoaded(info.dict) and GetGameTimer() < deadline do Wait(0) end
            end
            if HasAnimDictLoaded(info.dict) and actor.emoteLoop and actor.emoteInfo == info then
              local flags = 1 + (info.moving and 48 or 0)
              TaskPlayAnim(ped, info.dict, info.clip, 3.0, 3.0, -1, flags, 0.0, false, false, false)
              RemoveAnimDict(info.dict)
            end
          end
        end
      end
    end
  end
end)

RegisterNetEvent('immerse_actors:emoteResponse', function(requestId, info, message)
  local id = pendingEmotes[requestId]
  pendingEmotes[requestId] = nil
  if not id then return end
  if not info then notify(message or 'Emote not found', 'error'); return end
  local actor = actorById(id)
  if actor then applyEmote(actor, info, message) end
end)

RegisterNetEvent('immerse_actors:status', function(value)
  statusText = value or 'No RPEmotes found'
  SendNUIMessage({ type = 'status', text = statusText })
end)

RegisterCommand('sceneactors_menu', function()
  if menuOpen then closeMenu() else showMenu() end
end, false)
RegisterCommand('actors', function() if menuOpen then closeMenu() else showMenu() end end, false)
RegisterCommand('sceneactors_camera', function()
  if freecam then exitCamera() else enterCamera() end
end, false)
RegisterKeyMapping('sceneactors_menu', 'Immerse Actors: open actor menu', 'keyboard', 'F6')
RegisterKeyMapping('sceneactors_camera', 'Immerse Actors: toggle free camera', 'keyboard', 'F9')

RegisterNUICallback('closeMenu', function(_, cb) closeMenu(); cb({ok = true}) end)
RegisterNUICallback('clone', function(_, cb)
  createActor()
  cb({ok = true})
end)
RegisterNUICallback('camera', function(_, cb)
  if menuOpen then closeMenu() end
  if not freecam then enterCamera() else exitCamera() end
  cb({ok = true})
end)
RegisterNUICallback('inspect', function(data, cb)
  local id = tonumber(data.id)
  if id and actorById(id) then
    if menuOpen then closeMenu() end
    if not freecam then enterCamera() end
    showEditor(id)
  end
  cb({ok = true})
end)
RegisterNUICallback('closeEditor', function(_, cb) stopEditor(); cb({ok = true}) end)
RegisterNUICallback('exitCamera', function(_, cb) exitCamera(); cb({ok = true}) end)
RegisterNUICallback('actorAction', function(data, cb)
  local actor = selectedId and actorById(selectedId) or nil
  local action = tostring(data.action or '')
  if actor then
    if action == 'freeze' then
      if actor.behavior ~= 'idle' then
        holdActor(actor)
      else
        actor.frozen = not actor.frozen
        FreezeEntityPosition(actor.ped, actor.frozen)
      end
      pushActors(); pushDetails()
    elseif action == 'behavior' then
      local behavior = tostring(data.value or '')
      if startBehavior(actor, behavior) then
        if behavior == 'follow' or behavior == 'fight' then
          stopEditor()
          exitCamera() -- Return control to the player before an actor attacks/follows.
        end
      end
    elseif action == 'move' then
      moveActor(selectedId)
    elseif action == 'delete' then
      local id = selectedId
      stopEditor()
      deleteActor(id)
      notify('Actor deleted.', 'success')
    elseif action == 'clearEmote' then
      holdActor(actor)
      pushActors(); pushDetails()
    elseif action == 'weapon' then
      setWeapon(actor, tostring(data.value or 'none'))
    elseif action == 'emoteLoop' then
      actor.emoteLoop = data.value == true
      if actor.emoteInfo and actor.emote ~= 'None' then
        -- Reapply the current clip with the new loop flag/duration.
        local code, info = actor.emote, actor.emoteInfo
        applyEmote(actor, info, code)
      else
        pushActors(); pushDetails()
      end
      notify(actor.emoteLoop and 'This actor will keep looping its emote.' or
        'Continuous emote looping disabled.', 'success')
    elseif action == 'emote' then
      local code = tostring(data.value or '')
      if #code > 75 then
        notify('Emote code is too long.', 'error')
      else
        requestSerial = requestSerial + 1
        pendingEmotes[requestSerial] = selectedId
        TriggerServerEvent('immerse_actors:requestEmote', requestSerial, code)
      end
    elseif action == 'rotateLeft' or action == 'rotateRight' then
      local sign = action == 'rotateLeft' and -1 or 1
      SetEntityHeading(actor.ped, (GetEntityHeading(actor.ped) + 15 * sign) % 360)
    end
  end
  cb({ok = true})
end)
RegisterNUICallback('bringToMe', function(data, cb)
  local id = tonumber(data.id)
  local success = false
  if menuOpen and id and actorById(id) then
    success = bringActorToPlayer(id)
  end
  cb({ok = success})
end)
RegisterNUICallback('deleteFromList', function(data, cb)
  if menuOpen then
    deleteActor(tonumber(data.id))
    notify('Actor deleted.', 'success')
  end
  cb({ok = true})
end)

RegisterNUICallback('spawnCrowd', function(data,cb)
  if creatingCrowd then cb({ok=false,error='Already spawning'});return end
  if not menuOpen then cb({ok=false,error='Open /actors first'});return end
  local preset=tostring(data.preset or '')
  local count=tonumber(data.count) or 12
  local formation=tostring(data.formation or 'scatter')
  local spacing=tonumber(data.spacing) or 1.8
  local mood=tostring(data.mood or 'carmeet')
  if not Config.CrowdPresets[preset] then cb({ok=false,error='Invalid crowd type'});return end
  -- Respond before async ped model streaming (never block the NUI request).
  cb({ok=true})
  CreateThread(function() createCrowd(preset,count,formation,spacing,mood) end)
end)
RegisterNUICallback('moveCrowd',function(data,cb)
  if menuOpen and groups[tonumber(data.id)] then
    moveCrowd(tonumber(data.id));cb({ok=true})
  else cb({ok=false}) end
end)
RegisterNUICallback('deleteCrowd',function(data,cb)
  if menuOpen then deleteCrowd(tonumber(data.id));cb({ok=true})
  else cb({ok=false}) end
end)
RegisterNUICallback('reshuffleCrowd',function(data,cb)
  local group=menuOpen and groups[tonumber(data.id)] or nil
  if group then requestGroupEmotes(group);cb({ok=true}) else cb({ok=false}) end
end)

RegisterNUICallback('deleteAll', function(_, cb)
  if menuOpen then
    local ids = {}
    for id in pairs(actors) do ids[#ids + 1] = id end
    for _, id in ipairs(ids) do deleteActor(id,true) end
    pushActors();pushGroups();pushDetails()
    notify('All your scene actors were removed.', 'success')
  end
  cb({ok = true})
end)

-- Freecam and precise placement. Editing uses normal NUI mouse focus and pauses camera movement.
CreateThread(function()
  local lastHoverSent = 0
  local moveRayHandle = nil
  while true do
    if not freecam then Wait(250)
    else
      Wait(0)
      DisableAllControlActions(0)
      EnableControlAction(0, 249, true) -- voice
      HideHudAndRadarThisFrame()
      if activeCam == 0 then exitCamera(); goto skip end
      if not editorOpen then
        if IsDisabledControlJustPressed(0, 200) then exitCamera(); goto skip end
        local frame = clamp(GetFrameTime() * 60.0, 0.05, 3.0)
        local mouseX = GetDisabledControlNormal(0, 1)
        local mouseY = GetDisabledControlNormal(0, 2)
        cameraRotation = vector3(
          clamp(cameraRotation.x - mouseY * Config.MouseSensitivity * frame, -89.0, 89.0),
          0.0,
          (cameraRotation.z - mouseX * Config.MouseSensitivity * frame) % 360.0)
        local dir = getDirection(cameraRotation)
        local yaw = math.rad(cameraRotation.z)
        local right = vector3(math.cos(yaw), math.sin(yaw), 0.0)
        local speed = Config.CameraSpeed * frame
        if IsDisabledControlPressed(0, 21) then speed = speed * Config.CameraFastMultiplier end
        if IsDisabledControlPressed(0, 19) then speed = speed * Config.CameraSlowMultiplier end
        if IsDisabledControlPressed(0, 32) then cameraPosition = cameraPosition + dir * speed end
        if IsDisabledControlPressed(0, 33) then cameraPosition = cameraPosition - dir * speed end
        if IsDisabledControlPressed(0, 35) then cameraPosition = cameraPosition + right * speed end
        if IsDisabledControlPressed(0, 34) then cameraPosition = cameraPosition - right * speed end
        if IsDisabledControlPressed(0, 22) then cameraPosition = cameraPosition + vector3(0,0,speed) end
        if IsDisabledControlPressed(0, 36) then cameraPosition = cameraPosition - vector3(0,0,speed) end
        SetCamCoord(activeCam, cameraPosition.x, cameraPosition.y, cameraPosition.z)
        SetCamRot(activeCam, cameraRotation.x, cameraRotation.y, cameraRotation.z, 2)
        if groupMoveState then
          cameraHoverProbe=nil
          cameraHoverBlockDistance=nil
          local state=groupMoveState
          local group=groups[state.id]
          if not group then
            stopGroupMove(false)
          else
            if IsDisabledControlJustPressed(0,14) then state.spacing=clamp(state.spacing-0.12,1.15,4.0) end
            if IsDisabledControlJustPressed(0,15) then state.spacing=clamp(state.spacing+0.12,1.15,4.0) end
            if IsDisabledControlPressed(0,44) then state.heading=(state.heading-frame*1.3)%360 end
            if IsDisabledControlPressed(0,38) then state.heading=(state.heading+frame*1.3)%360 end
            if IsDisabledControlJustPressed(0,20) then state.height=clamp(state.height-0.1,-2.0,5.0) end -- Z
            if IsDisabledControlJustPressed(0,73) then state.height=clamp(state.height+0.1,-2.0,5.0) end -- X
            if state.ray then
              local result,hit,coords,normal=GetShapeTestResult(state.ray)
              if result==2 then
                if (hit==true or hit==1) and normal and normal.z>0.35 then
                  state.point=coords;state.valid=true
                else
                  local fallback=cameraPosition+dir*12.0
                  local found,z=GetGroundZFor_3dCoord(fallback.x,fallback.y,fallback.z+25.0,false)
                  state.point=found and vector3(fallback.x,fallback.y,z) or nil
                  state.valid=found
                end
                state.ray=nil
              elseif result==0 then state.ray=nil end
            end
            if not state.ray then
              local target=cameraPosition+dir*Config.MaximumCameraRange
              state.ray=StartShapeTestLosProbe(cameraPosition.x,cameraPosition.y,cameraPosition.z,
                target.x,target.y,target.z,1+2+16,PlayerPedId(),7)
            end
            if state.valid and state.point then
              -- Reposition every ~85ms to reduce cost of querying ground for large crowds.
              if GetGameTimer()-state.groundTick>85 then
                placeGroupAt(group,state.point,state.heading,state.spacing,state.height)
                state.groundTick=GetGameTimer()
              end
            end
            if IsDisabledControlJustPressed(0,24) then
              if state.valid then
                stopGroupMove(true)
                notify('Crowd placed. Actors can still be edited individually.','success')
              else notify('Aim at a street or floor to place the crowd.','error') end
            end
            if IsDisabledControlJustPressed(0,25) then
              stopGroupMove(false)
              notify('Crowd move cancelled.')
            end
          end
          hoveredId=nil
        elseif movingId then
          cameraHoverProbe = nil
          cameraHoverBlockDistance = nil
          local actor = actorById(movingId)
          if not actor or not exists(actor.ped) then stopMove(false)
          else
            if IsDisabledControlJustPressed(0, 14) then moveHeight = moveHeight - 0.05 end
            if IsDisabledControlJustPressed(0, 15) then moveHeight = moveHeight + 0.05 end
            if IsDisabledControlPressed(0, 44) then moveHeading = (moveHeading - frame * 1.3) % 360 end
            if IsDisabledControlPressed(0, 38) then moveHeading = (moveHeading + frame * 1.3) % 360 end
            -- Read the previous frame's async ray and determine a WALKABLE Z.
            if moveRayHandle then
              local result, didHit, endCoords, normal = GetShapeTestResult(moveRayHandle)
              if result == 2 then
                local hit = didHit == true or didHit == 1
                local point = hit and endCoords or cameraPosition + dir * 9.0
                if hit and (not normal or normal.z > 0.45) then
                  actor.lastMovePoint = point
                  actor.lastMoveValid = true
                else
                  -- Wall/sky: find actual ground below/near the pointed position.
                  local found, groundZ = GetGroundZFor_3dCoord(point.x, point.y, point.z + 12.0, false)
                  actor.lastMoveValid = found
                  actor.lastMovePoint = found and vector3(point.x, point.y, groundZ) or nil
                end
                moveRayHandle = nil
              elseif result == 0 then
                moveRayHandle = nil
              end
            end
            if not moveRayHandle then
              local target = cameraPosition + dir * Config.MaximumCameraRange
              moveRayHandle = StartShapeTestLosProbe(cameraPosition.x, cameraPosition.y, cameraPosition.z,
                target.x, target.y, target.z, 1+2+16, actor.ped, 7)
            end
            if actor.lastMoveValid and actor.lastMovePoint then
              local point = actor.lastMovePoint
              -- IMPORTANT: this native accepts GROUND Z; it adds the ped's origin offset.
              SetEntityCoords(actor.ped, point.x, point.y,
                point.z + moveHeight + (Config.PlacementLift or 0.02), false, false, false, false)
              SetEntityHeading(actor.ped, moveHeading)
            end
            if IsDisabledControlJustPressed(0, 24) then
              if actor.lastMoveValid then
                stopMove(true); notify('Actor placed on the surface.', 'success')
              else
                notify('Aim at a floor or road to place the actor.', 'error')
              end
            end
            if IsDisabledControlJustPressed(0, 25) then stopMove(false); notify('Move cancelled.') end
          end
          hoveredId = nil
        else
          moveRayHandle = nil
          if IsDisabledControlJustPressed(0, 14) then cameraFov = clamp(cameraFov + 2.5, 18, 95) end
          if IsDisabledControlJustPressed(0, 15) then cameraFov = clamp(cameraFov - 2.5, 18, 95) end
          SetCamFov(activeCam, cameraFov)
          -- Ray and bone positions are both based on the rendered camera center.
          local actualPos, actualRot = GetCamCoord(activeCam), GetCamRot(activeCam, 2)
          local actualDir = getDirection(actualRot)
          local blockedAt = updateCameraOcclusion(actualPos, actualDir)
          hoveredId = pickActor(actualPos, actualDir, blockedAt)
          if hoveredId and IsDisabledControlJustPressed(0, 25) then
            showEditor(hoveredId)
          end
        end
        if GetGameTimer() - lastHoverSent > 70 then
          SendNUIMessage({type='hover', active=hoveredId ~= nil, moving=movingId ~= nil, groupMoving=groupMoveState ~= nil })
          lastHoverSent = GetGameTimer()
        end
      end
      ::skip::
    end
  end
end)

-- Avoid orphan clones when stopping/restarting the resource.
AddEventHandler('onResourceStop', function(resource)
  if resource ~= GetCurrentResourceName() then return end
  if freecam then exitCamera() end
  if menuOpen then closeMenu() end
  local ids = {}
  for id in pairs(actors) do ids[#ids + 1] = id end
  for _, id in ipairs(ids) do deleteActor(id,true) end
  stopFocus()
end)
