Config = {}

-- Command /actors or F6 opens the actor list; F9 toggles the camera.
Config.MaxActors = 85 -- includes both clones and crowd members
Config.NetworkedActors = false -- false = personal filming setup; true = replicated actors (requires OneSync; test permissions/sync)
Config.CameraSpeed = 0.22
Config.CameraFastMultiplier = 3.7
Config.CameraSlowMultiplier = 0.32
Config.MouseSensitivity = 7.5
Config.MaximumCameraRange = 160.0
Config.DefaultFov = 65.0
Config.PlacementLift = 0.02 -- slight floor clearance, meters
Config.FollowSpeed = 1.5
Config.LeaveAreaDistance = 25.0 -- meters walked away before ambient roaming
Config.LeaveWalkSpeed = 1.05
Config.EmoteLoopDefault = false -- players opt in with Keep emote looping
Config.EmoteLoopCheckMs = 950 -- check and resume any interrupted loops

-- RPEmotes folder name(s), even if renamed on your server. See README.
Config.EmoteResources = { 'rpemotes', 'rpemotes-reborn', 'dpemotes' }
-- Custom definitions in this script are read from emotes.json.
Config.EmoteFilePaths = {
  'client/AnimationList.lua',
  'client/AnimationListCustom.lua',
  'Client/AnimationList.lua',
  'Client/AnimationListCustom.lua'
}

Config.Weapons = {
  { label = 'No weapon', name = 'none' },
  { label = 'Pistol', name = 'WEAPON_PISTOL' },
  { label = 'Combat Pistol', name = 'WEAPON_COMBATPISTOL' },
  { label = 'Heavy Pistol', name = 'WEAPON_HEAVYPISTOL' },
  { label = 'Stun Gun', name = 'WEAPON_STUNGUN' },
  { label = 'Flashlight', name = 'WEAPON_FLASHLIGHT' },
  { label = 'Carbine Rifle', name = 'WEAPON_CARBINERIFLE' },
  { label = 'Pump Shotgun', name = 'WEAPON_PUMPSHOTGUN' },
  { label = 'SMG', name = 'WEAPON_SMG' },
  { label = 'Nightstick', name = 'WEAPON_NIGHTSTICK' }
}


-- v1.3 Crowd Builder: use /actors > Crowds. Client-local by default.
Config.MinCrowdSize = 3
Config.MaxCrowdSize = 30 -- protect FPS: spawn in small batches on weaker PCs
Config.MaxCrowds = 6
Config.CrowdFormations = {
  scatter = {label='Natural crowd',description='Mixed, slightly irregular spacing'},
  line = {label='Line / spectators',description='Multiple rows of onlookers'},
  arc = {label='Arc around cars',description='A curved audience-facing arrangement'}
}

-- All model names are vanilla GTA. Models missing on a particular game build
-- are ignored. Add custom model names here if those models are streamed.
Config.CrowdPresets = {
  ballas = {label='Ballas',description='A varied group of Ballas gang pedestrians',
    models={'g_m_y_ballaeast_01','g_m_y_ballaorig_01','g_m_y_ballasout_01','g_f_y_ballas_01'}},
  families = {label='Families',description='Families from South Los Santos',
    models={'g_m_y_famca_01','g_m_y_famdnf_01','g_m_y_famfor_01','g_f_y_families_01'}},
  vagos = {label='Vagos',description='East LS street pedestrians',
    models={'g_m_y_mexgoon_01','g_m_y_mexgoon_02','g_m_y_mexgoon_03','g_f_y_vagos_01'}},
  vinewood = {label='Vinewood / city',description='A mix of upscale, business, and trendy civilians',
    models={'a_m_y_vinewood_01','a_m_y_vinewood_02','a_m_y_vinewood_03','a_m_y_vinewood_04',
      'a_f_y_vinewood_01','a_f_y_vinewood_02','a_f_y_vinewood_03','a_f_y_vinewood_04',
      'a_m_y_hipster_01','a_f_y_hipster_01','a_m_m_business_01','a_f_m_business_02',
      'a_m_y_bevhills_01','a_f_y_bevhills_01','a_m_y_business_01'}},
  carmeet = {label='Car meet',description='Car enthusiasts, spectators and creators',
    models={'a_m_y_stbla_01','a_m_y_stbla_02','a_m_y_stwhi_01','a_m_y_stwhi_02',
      'a_m_y_hipster_01','a_m_y_hipster_02','a_m_y_hipster_03','a_f_y_hipster_01',
      'a_f_y_hipster_02','a_f_y_hipster_03','a_m_y_skater_01','a_m_y_skater_02',
      'a_m_y_soucent_01','a_m_y_soucent_02','a_f_y_soucent_01','a_f_y_soucent_02'}},
  party = {label='Club / rave',description='Mixed clubgoers, dancers, and nightlife spectators',
    models={'a_m_y_clubcust_01','a_m_y_clubcust_02','a_m_y_clubcust_03',
      'a_f_y_clubcust_01','a_f_y_clubcust_02','a_f_y_clubcust_03',
      'a_m_y_hipster_01','a_m_y_hipster_02','a_f_y_hipster_01','a_f_y_hipster_02',
      'a_m_y_vinewood_02','a_f_y_vinewood_03'}},
  beach = {label='Beach / festival',description='Relaxed outdoor crowds and festivalgoers',
    models={'a_m_y_beach_01','a_m_y_beach_02','a_m_y_beach_03','a_f_y_beach_01',
      'a_f_y_beach_02','a_m_m_beach_01','a_f_m_beach_01','a_m_y_hipster_02',
      'a_f_y_hipster_03'}},
  mixed = {label='Los Santos mix',description='A diverse mix of ordinary GTA civilians',
    models={'a_m_y_hipster_01','a_m_y_hipster_02','a_f_y_hipster_01','a_f_y_hipster_02',
      'a_m_y_soucent_01','a_m_y_soucent_02','a_f_y_soucent_01','a_f_y_soucent_02',
      'a_m_y_stbla_01','a_m_y_stwhi_01','a_m_m_business_01','a_f_m_business_02',
      'a_m_y_vinewood_01','a_f_y_vinewood_02','a_m_y_beach_01','a_f_y_beach_01'}}
}

-- Crowd emotes are looked up in RPEmotes Reborn (without re-uploading its files).
-- Missing emote codes are skipped; available ones are shuffled so actors differ.
Config.CrowdMoods = {
  carmeet = {label='Car meet / filming',emotes={'record','selfie','camera','phone','crossarms','clap2','cheer','wait','dance','dance3','dance2','smoke'}},
  hype = {label='Hype / celebration',emotes={'dance','dance2','dance3','dance4','dance5','clap2','cheer','wave','record','selfie'}},
  party = {label='Club / rave',emotes={'dance','dance2','dance3','dance4','dance5','dance6','dance7','dance8','dance9','clap2','record','selfie'}},
  chill = {label='Relaxed / casual',emotes={'clap2','phone','crossarms','wait','sit','smoke','clipboard','wave'}},
  photos = {label='Photos / fans',emotes={'record','selfie','camera','phone','clap2','cheer','wave','dance3'}}
}
