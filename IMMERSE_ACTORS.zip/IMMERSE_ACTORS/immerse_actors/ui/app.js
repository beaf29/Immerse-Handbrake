(() => {
  const $ = (selector) => document.querySelector(selector);
  const menu = $('#menu');
  const cameraHud = $('#cameraHud');
  const editor = $('#editor');
  const crosshair = $('#crosshair');
  const actorList = $('#actorList');
  const sourceLabel = $('#sourceLabel');
  let actors = [], groups = [], maxActors = 85, selected = null, weapons = [], clearArmed = false;
  let presets = {}, moods = {}, formations = {}, activeTab = 'actors';
  let menuVisible = false, editorVisible = false, cameraVisible = false;

  async function invoke(action, payload = {}) {
    try {
      if (typeof GetParentResourceName !== 'function') return;
      const response = await fetch(`https://${GetParentResourceName()}/${action}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload)
      });
      return await response.json();
    } catch (err) { console.warn('Scene Actors callback failed:', err); }
  }
  function toast(text, level = 'info') {
    const entry = document.createElement('div');
    entry.className = `toast ${level}`;
    entry.textContent = String(text);
    $('#toastContainer').append(entry);
    setTimeout(() => entry.remove(), 3400);
  }
  function show(node, visible) { node.classList.toggle('hidden', !visible); }
  function renderActors() {
    const query = $('#actorSearch').value.trim().toLowerCase();
    const matching = actors.filter(actor => `${actor.label} ${actor.emote} ${actor.weapon} ${actor.behavior || 'idle'}`.toLowerCase().includes(query));
    $('#actorCounter').textContent = actors.length;
    $('#actorMax').textContent = maxActors;
    actorList.replaceChildren();
    if (!matching.length) {
      const empty = document.createElement('div'); empty.className = 'empty';
      const symbol = document.createElement('div'); symbol.className = 'empty-symbol'; symbol.textContent = '⊹';
      const title = document.createElement('strong'); title.textContent = query ? 'No matching actors' : 'Your scene is empty';
      const subtitle = document.createElement('small'); subtitle.textContent = query ? 'Try a different search' : 'Clone your MP ped to create your first actor';
      empty.append(symbol, title, subtitle); actorList.append(empty); return;
    }
    matching.forEach(actor => {
      const row = document.createElement('div'); row.className = 'actor-row';
      const icon = document.createElement('div'); icon.className = 'actor-icon'; icon.textContent = '♙';
      const info = document.createElement('div'); info.className = 'actor-info';
      const name = document.createElement('div'); name.className = 'actor-name'; name.textContent = actor.label;
      const desc = document.createElement('div'); desc.className = 'actor-sub';
      desc.textContent = `${actor.groupId ? 'Crowd #' + actor.groupId + ' · ' : ''}${actor.behavior && actor.behavior !== 'idle' ? actor.behavior.toUpperCase() : (actor.frozen ? 'Frozen' : 'Unfrozen')} · ${actor.emote === 'None' ? 'No animation' : actor.emote} · ${actor.weapon === 'none' ? 'Unarmed' : actor.weapon.replace('WEAPON_', '')}`;
      info.append(name, desc);
      const bring = document.createElement('button'); bring.className = 'bring-cta'; bring.textContent = 'Bring to me';
      bring.title = 'Teleport this actor to the ground in front of your character';
      bring.onclick = () => invoke('bringToMe', {id: actor.id});
      const edit = document.createElement('button'); edit.className = 'actor-cta'; edit.textContent = 'Edit in camera';
      edit.onclick = () => invoke('inspect', {id: actor.id});
      const remove = document.createElement('button'); remove.className = 'small-delete'; remove.textContent = '×'; remove.title = 'Delete actor';
      remove.onclick = () => invoke('deleteFromList', {id: actor.id});
      row.append(icon, info, bring, edit, remove); actorList.append(row);
    });
  }

  function setTab(tab) {
    activeTab = tab === 'crowds' ? 'crowds' : 'actors';
    document.querySelectorAll('.workspace-tab').forEach(btn => btn.classList.toggle('active', btn.dataset.tab === activeTab));
    show($('#actorsPage'), activeTab === 'actors');
    show($('#crowdsPage'), activeTab === 'crowds');
  }
  document.querySelectorAll('.workspace-tab').forEach(btn => btn.onclick = () => setTab(btn.dataset.tab));
  function fillSelect(node, options, chosen) {
    const current = chosen || node.value;
    node.replaceChildren();
    Object.entries(options || {}).forEach(([key, item]) => {
      const opt = document.createElement('option'); opt.value=key; opt.textContent=item.label || key;
      node.append(opt);
    });
    if (options && options[current]) node.value=current;
  }
  function populateCrowdSettings() {
    fillSelect($('#crowdPreset'), presets, 'carmeet');
    fillSelect($('#crowdFormation'), formations, 'scatter');
    fillSelect($('#crowdMood'), moods, 'carmeet');
    $('#crowdPresetDesc').textContent = presets[$('#crowdPreset').value]?.description || '';
  }
  function updateCrowdSliders() {
    $('#crowdCountText').textContent=$('#crowdCount').value;
    $('#crowdSpacingText').textContent=Number($('#crowdSpacing').value).toFixed(2) + 'm';
  }
  $('#crowdCount').oninput=updateCrowdSliders;
  $('#crowdSpacing').oninput=updateCrowdSliders;
  $('#crowdPreset').onchange=()=>$('#crowdPresetDesc').textContent=presets[$('#crowdPreset').value]?.description || '';
  function renderCrowds() {
    const list=$('#crowdGroupList');list.replaceChildren();
    if (!groups.length) {
      const empty=document.createElement('div');empty.className='crowd-empty';
      empty.textContent='No crowds yet. Choose a background and create your first group.';
      list.append(empty);return;
    }
    groups.forEach(group=>{
      const row=document.createElement('div');row.className='crowd-group';
      const title=document.createElement('div');title.className='crowd-group-title';
      const strong=document.createElement('strong');strong.textContent=group.name;
      const sub=document.createElement('span');sub.textContent=`${group.count} peds · ${moods[group.mood]?.label || group.mood} · ${formations[group.formation]?.label || group.formation}`;
      title.append(strong,sub);
      const move=document.createElement('button');move.textContent='Position';move.onclick=()=>invoke('moveCrowd',{id:group.id});
      const reshuffle=document.createElement('button');reshuffle.textContent='New emotes';reshuffle.onclick=()=>invoke('reshuffleCrowd',{id:group.id});
      const remove=document.createElement('button');remove.className='group-delete';remove.textContent='Delete';remove.onclick=()=>{
        if (remove.dataset.confirm === 'yes') invoke('deleteCrowd',{id:group.id});
        else {remove.dataset.confirm='yes'; remove.textContent='Confirm';setTimeout(()=>{if(remove.isConnected){remove.textContent='Delete';delete remove.dataset.confirm;}},2800);}
      };
      row.append(title,move,reshuffle,remove);list.append(row);
    });
  }
  $('#spawnCrowd').onclick=async()=>{
    const button=$('#spawnCrowd'); button.disabled=true;button.textContent='Creating crowd...';
    const response=await invoke('spawnCrowd',{
      preset:$('#crowdPreset').value,count:Number($('#crowdCount').value),
      formation:$('#crowdFormation').value,spacing:Number($('#crowdSpacing').value),mood:$('#crowdMood').value
    });
    if (response && response.ok===false) toast(response.error || 'Crowd not created','error');
    button.disabled=false;button.textContent='+ Create & position crowd';
  };

  function renderDetail() {
    if (!selected) return;
    $('#editorTitle').textContent = selected.label;
    $('#actorFrozenText').textContent = selected.behavior && selected.behavior !== 'idle' ? selected.behavior.toUpperCase() : (selected.frozen ? 'FROZEN IN PLACE' : 'UNFROZEN');
    $('#actorEmoteText').textContent = selected.emote === 'None' ? 'NO ANIMATION' : selected.emote.toUpperCase();
    $('#freezeLabel').textContent = selected.frozen ? 'Unfreeze' : 'Freeze';
    $('#weaponSelect').value = selected.weapon || 'none';
    $('#emoteLoop').checked = !!selected.emoteLoop;
    const modes = {idle:'Holding position',follow:'Following you',fight:'Attacking you',leave:'Leaving scene',ambient:'Ambient wandering'};
    $('#behaviorStatus').textContent = 'Current: ' + (modes[selected.behavior || 'idle'] || 'Holding position');
    document.querySelectorAll('[data-mode]').forEach(node => node.classList.toggle('behavior-active', node.dataset.mode === selected.behavior));
  }
  function populateWeapons() {
    const select = $('#weaponSelect'); select.replaceChildren();
    for (const weapon of weapons) {
      const option = document.createElement('option'); option.value = weapon.name; option.textContent = weapon.label;
      select.append(option);
    }
    renderDetail();
  }
  function closeEditor() {invoke('closeEditor');}
  $('#closeMenu').onclick = () => invoke('closeMenu');
  $('#cloneBtn').onclick = () => invoke('clone');
  $('#cameraBtn').onclick = () => invoke('camera');
  $('#actorSearch').oninput = renderActors;
  $('#clearAllBtn').onclick = () => {
    if (!clearArmed) {
      clearArmed = true; $('#clearAllBtn').textContent = 'Confirm clear all';
      setTimeout(() => { clearArmed = false; $('#clearAllBtn').textContent = 'Clear all'; }, 3500);
    } else {
      clearArmed = false; $('#clearAllBtn').textContent = 'Clear all'; invoke('deleteAll');
    }
  };
  $('#closeEditor').onclick = closeEditor;
  $('#moveBtn').onclick = () => invoke('actorAction', {action: 'move'});
  $('#freezeBtn').onclick = () => invoke('actorAction', {action: 'freeze'});
  document.querySelectorAll('[data-mode]').forEach(button => {
    button.onclick = () => invoke('actorAction', {action: 'behavior', value: button.dataset.mode});
  });
  $('#rotateLeft').onclick = () => invoke('actorAction', {action: 'rotateLeft'});
  $('#rotateRight').onclick = () => invoke('actorAction', {action: 'rotateRight'});
  $('#weaponSelect').onchange = () => invoke('actorAction', {action: 'weapon', value: $('#weaponSelect').value});
  function playEmote() {
    const code = $('#emoteCode').value.trim();
    if (!code) {toast('Enter an emote code first.', 'error');return;}
    invoke('actorAction', {action: 'emote', value: code});
  }
  $('#playEmote').onclick = playEmote;
  $('#emoteLoop').onchange = () => invoke('actorAction', {action: 'emoteLoop', value: $('#emoteLoop').checked});
  $('#emoteCode').addEventListener('keydown', e => {if(e.key === 'Enter') playEmote();});
  document.querySelectorAll('[data-emote]').forEach(button => {
    button.onclick = () => { $('#emoteCode').value = button.dataset.emote; playEmote(); };
  });
  $('#stopEmote').onclick = () => invoke('actorAction', {action: 'clearEmote'});
  $('#deleteActor').onclick = () => invoke('actorAction', {action: 'delete'});
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      e.preventDefault();
      if (editorVisible) closeEditor(); else if (menuVisible) invoke('closeMenu');
    }
    if (e.key === 'F9' && (editorVisible || menuVisible)) {
      e.preventDefault(); if (menuVisible) invoke('camera'); else invoke('exitCamera');
    }
  });
  window.addEventListener('message', event => {
    const m = event.data || {};
    switch (m.type) {
      case 'menu':
        menuVisible = !!m.show; show(menu, menuVisible);
        if (m.actors) actors = m.actors;
        if (m.maxActors) maxActors = m.maxActors;
        if (m.weapons) weapons = m.weapons;
        if (m.source) sourceLabel.textContent = 'SOURCE: ' + m.source;
        if (m.presets) presets = m.presets;
        if (m.moods) moods = m.moods;
        if (m.formations) formations = m.formations;
        if (m.maxCrowdSize) $('#crowdCount').max=String(m.maxCrowdSize);
        if (m.groups) groups=m.groups;
        populateCrowdSettings(); updateCrowdSliders(); renderCrowds(); renderActors(); break;
      case 'camera':
        cameraVisible = !!m.show; show(cameraHud, cameraVisible);
        if (!cameraVisible) {editorVisible = false; show(editor, false);}
        break;
      case 'editor':
        editorVisible = !!m.show; show(editor, editorVisible);
        if (m.weapons) {weapons = m.weapons; populateWeapons();}
        if (m.source) sourceLabel.textContent = 'SOURCE: ' + m.source;
        break;
      case 'actorDetail': selected = m.actor || null; renderDetail(); break;
      case 'actors': actors = m.actors || []; renderActors(); break;
      case 'groups': groups=m.groups || []; renderCrowds();break;
      case 'groupMove': {
        crosshair.classList.toggle('group-placing',!!m.active);
        const hint=$('#cameraHint');hint.classList.toggle('group-hint',!!m.active);
        if (m.active) hint.textContent=`${m.label || 'CROWD'} · ${m.count || 0} PEDS  ·  Q/E ROTATE  ·  WHEEL SPACING  ·  Z/X HEIGHT  ·  LEFT CLICK PLACE  ·  RIGHT CLICK CANCEL`;
        else hint.innerHTML='WASD MOVE <span>·</span> MOUSE LOOK <span>·</span> SPACE / CTRL HEIGHT <span>·</span> SHIFT FAST <span>·</span> RIGHT CLICK ACTOR';
        break;
      }
      case 'status': sourceLabel.textContent = 'SOURCE: ' + (m.text || 'Unknown'); break;
      case 'hover': crosshair.classList.toggle('target', !!m.active && !m.groupMoving); break;
      case 'moving':
        crosshair.classList.toggle('placing', !!m.active);
        $('#cameraHint').innerHTML = m.active
          ? 'WASD MOVE CAMERA <span>·</span> Q / E ROTATE ACTOR <span>·</span> WHEEL ADJUST HEIGHT <span>·</span> LEFT CLICK PLACE <span>·</span> RIGHT CLICK CANCEL'
          : 'WASD MOVE <span>·</span> MOUSE LOOK <span>·</span> SPACE / CTRL HEIGHT <span>·</span> SHIFT FAST <span>·</span> RIGHT CLICK ACTOR';
        break;
      case 'toast': toast(m.text || '', m.level); break;
    }
  });
})();
