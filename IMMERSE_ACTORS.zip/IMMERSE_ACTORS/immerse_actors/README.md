Immerse Actors — Installation & Usage

Standalone cinematic tool for cloning your MP character and staging populated scenes with editable GTA pedestrian crowds. No ESX, QBCore, ox_lib, or database required. RPEmotes is recommended for its full emote catalog; built-in GTA emotes can be used without it.

For a visual drag-and-drop guide, open `INSTALL.html` in the root of the downloaded ZIP.

## Installation

1. Drop the `immerse_actors` directory into your FiveM server's `resources` folder.
2. Add `ensure immerse_actors` to `server.cfg`.
3. Start the server, enter as your MP ped, and use `/actors` (or **F6**) to open the menu.
4. Click **Clone current ped** and press **F9** to use the scene camera.
5. Aim the small crosshair at a cloned ped. It turns green. **Right-click** to open actor options.

## Controls

| Input | Action |
| --- | --- |
| F6 or `/actors` | Open/close actor menu |
| F9 | Enter/exit scene freecam |
| WASD | Move freecam |
| Mouse | Look around |
| Space / Left Ctrl | Raise / lower camera |
| Shift / Alt | Faster / slower camera |
| Mouse wheel | Adjust freecam FOV, unless placing actor |
| Green + / Right-click | Inspect cloned actor |
| Right-click actor > Move / Place | Enter actor placement |
| Placement: WASD + mouse | Move the camera / aim position |
| Placement: Q/E | Rotate actor |
| Placement: wheel | Height offset (5 cm/step) |
| Placement: Left-click | Confirm actor position |
| Placement: Right-click | Cancel and revert position |
| ESC | Close menu / actor panel, or exit freecam if neither is open |

## Actor menu features

- Exact native **ClonePed** copy of your current ped (model, MP clothes, face/head blend, most visual variations). Some third-party tattoo/decal systems may not copy overlays.
- Local script-managed clone list, with search and individual/delete-all controls.
- Camera-to-ped selection using animated ped body bones, with a green crosshair aligned to the actor instead of an offset above it.
- Freeze/unfreeze and rotate in 15-degree steps.
- Move with corrected ground-level ped placement, configurable floor clearance, additional height adjustment, surface detection, and cancel-to-original-position.
- **Follow Me:** unfreeze the clone and make it walk behind your character. The camera closes so you can move normally.
- **Fight Me:** unfreeze and make the clone fight your character using its equipped weapon (fists if unarmed); camera closes before the fight.
- **Leave Area:** unfreeze, walk roughly 25 meters away using GTA navmesh, then roam using standard ambient AI. It remains in your local actor list until deleted.
- **Stop / Hold:** cancel any AI activity, remove active emotes, freeze the actor in place.
- Give a gun or tool using configured GTA weapon model names, or remove all weapons.
- Enter RPEmotes codes (`lean`, `wave`, `sit`, `cop`, etc.). The server looks up definitions in RPEmotes' AnimationList.lua files and returns the animation dictionary/clip or scenario.
- Supports common RPEmotes prop attachment metadata, including up to two attached props, if the model is available. Not every complex RPEmotes action (paired/shared dance, sync choreography, ptfx, vehicle emotes, custom multi-stage emotes) is supported.
- A built-in `emotes.json` fallback containing common base GTA poses. Add custom animation codes, or set `"override": true` on an entry to replace an existing RPEmotes definition.
- Automatic cleanup on deletion or resource stop.

## Official download links

- RPEmotes Reborn (recommended for full animation support): https://github.com/alberttheprince/rpemotes-reborn
- ox_lib (optional; **not used or required by Immerse Actors**): https://github.com/overextended/ox_lib/releases/latest

## RPEmotes integration

**RPEmotes exports are for the LOCAL PLAYER, not arbitrary NPCs.** This resource reads the RPEmotes definition *data* from `client/AnimationList.lua`, `client/AnimationListCustom.lua`, or the older `Client/...` case path via `LoadResourceFile()` on the server. It does not call `/e` on your character and does not execute RPEmotes source Lua.

- In `config.lua`, set `Config.EmoteResources = {'rpemotes', 'rpemotes-reborn', 'dpemotes'}` to the actual resource folder name used on your server; if you renamed it, enter that name.
- Start RPEmotes Reborn before this resource (if installed under its recommended folder name; otherwise use the actual folder name):

  ```cfg
  ensure rpemotes-reborn
  ensure immerse_actors
  ```
- Restart `immerse_actors` after updating the RPEmotes animation lists, or type `sceneactorsreload` into the **server console**.
- In the actor panel, type just the code (`lean`, `wave`, `sitchair`, or `/e lean` also works).
- Your RPEmotes stream files remain a dependency for **custom** dictionaries and props. Base GTA emotes work without RPEmotes installed if mapped in `emotes.json`.
- Complex RPEmotes options such as effects, custom ped swaps, on-vehicle restrictions and paired animations are intentionally not reproduced.

### Manual `emotes.json`

To define any code not present in RPEmotes, edit the provided `emotes.json`:

```json
{
  "myidle": {
    "kind": "anim",
    "dict": "amb@world_human_leaning@male@wall@back@foot_up@idle_a",
    "clip": "idle_a",
    "loop": true
  },
  "cop": { "kind": "scenario", "scenario": "WORLD_HUMAN_COP_IDLES" }
}
```

Restart the resource or use console `sceneactorsreload` to reload. JSON entries only override a matching RPEmotes code if they contain `"override": true`; otherwise the RPEmotes version is used. You can also specify `props` (model, bone number, six-element placement array) to attach objects to an animation.

## Visibility and synchronization

By default `Config.NetworkedActors = false`: scene peds are *client-local*, ideal for solo camera work, and automatically disappear if their creator disconnects. They will **not** show to other connected players. You may opt into `true` for experimental OneSync replication. Be aware that ownership migration, tasks and delete behavior may vary between servers; this mode needs live multi-client testing and does **not** save or share actor edit permissions. For serious multi-user filming, a server-authoritative actor registry would be the next step.

## Known limitations

- Scene setup is **not persistent** across reconnects/resource restarts; this intentionally prevents leftover peds.
- Camera ray selection is designed for spawned scene actors; it does not operate on random NPCs or player characters.
- A camera raycast helps exclude actors behind walls, while animated body-bone capsules provide precise aiming if GTA does not return the ped entity at camera range.
- Placement is best on solid world surfaces and interiors with GTA collision. Aiming into the sky without valid ground will be rejected rather than placing actors beneath terrain or floating.
- Some emotes need custom streamed files and some RPEmotes entries have advanced logic not representable by a simple TaskPlayAnim or scenario.
- FiveM changes and other resources may rebind F6/F9 or conflict over NUI focus; keybinds can be changed in FiveM key binding settings.

## Configuration

- `Config.MaxActors` — default 85 (including clones and crowd members); lower this on weaker machines
- `Config.NetworkedActors` — default false
- `Config.CameraSpeed`, `Config.CameraFastMultiplier`, `Config.CameraSlowMultiplier`, `Config.MouseSensitivity`
- `Config.MaximumCameraRange`, `Config.DefaultFov`, `Config.PlacementLift`, `Config.FollowSpeed`, `Config.LeaveAreaDistance`
- `Config.EmoteResources`, `Config.EmoteFilePaths`
- `Config.Weapons` — selector whitelist
- `Config.MinCrowdSize`, `Config.MaxCrowdSize`, `Config.MaxCrowds` — group limits
- `Config.CrowdPresets`, `Config.CrowdFormations`, `Config.CrowdMoods` — editable crowds and animation pools

### Validation

Static syntax/UI checks were run. **No live FiveM runtime was available here**; verify ped replication (if enabled), streamed custom emotes, and shape-test placements on your actual game build before deployment to a public server.

## v1.1 update / behavior notes

- Ped placement uses `SetEntityCoords` (ground-level Z) instead of `SetEntityCoordsNoOffset` (ped origin-level Z); this addresses the torso-in-the-road bug.
- Camera targeting uses actual animated body segments and an LOS world probe rather than an arbitrary offset from the ped origin.
- **Follow Me** and **Fight Me** return you to your player, because the character cannot run while you are in freecam.
- **Leave Area** runs a GTA navmesh task first, then `TaskWanderStandard`. NPC navigation can fail in custom map zones without valid pedestrian navmesh. The actor remains a managed clone, but its AI uses ambient wandering rules.
- **Fight Me** can injure or kill your player character. To use it safely during shooting setup, ensure you have the intended weapon/equipment before triggering it.
- Freezing, moving, or starting an emote stops any current scripted AI task so those modes do not fight each other.
- These changes have been syntax-checked; live FiveM gameplay testing is still needed to confirm navmesh behavior and ped height on your server build.

## v1.2 update — continuous emotes + Bring to Me

- In **F6 / `/actors`**, each cloned ped now has a **Bring to me** button beside **Edit in camera**. This places the selected clone about 2 meters in front of your actual player (not the freecam), facing you. Leave a vehicle first. If terrain height cannot be found in an interior, placement falls back to the player's floor elevation.
- The actor editor has a **Keep emote looping** toggle. When enabled, a valid RPEmotes animation uses a looping flag and an unlimited duration, even if its original definition has a short duration. If its task gets interrupted, the script checks periodically and resumes it. GTA scenarios are naturally persistent; this option also monitors/restarts them.
- Each clone keeps its own loop preference; setting it on one clone does not change others. Changing the preference on an actor already playing an emote restarts that animation with the new mode. **Stop animation**, behavior changes, or deletion cancel it.
- **Bring to me** safely stops follow/fight/wander behavior and holds the actor in the new location. If an idle emote is currently playing, the task and any attached emote props are preserved.
- Optional settings: `Config.EmoteLoopDefault` and `Config.EmoteLoopCheckMs`.

**Note:** "Keep emote looping" repeats animations; it does not freeze a single animation frame. In GTA, some scenario animations run indefinitely regardless of the setting until **Stop animation** is used.


## v1.3 Crowd Builder — create crowd scenes

Open `/actors` (F6), select **Crowd Builder** and choose the desired GTA pedestrian background:

- **Ballas**, **Families**, **Vagos** (GTA ambient gang pedestrian models).
- **Vinewood / city** (trendier and upscale civilians), **Car meet**, **Club / rave**, **Beach / festival**, or **Los Santos mix**.

Set **Group size** (3–30 by default), **Spacing**, **Formation** (natural crowd, line of spectators, or arc), and **Activity / emotes** (Car meet/filming, hype, rave, casual, photo crowd). Click **Create & position crowd**. Actors are spawned near your character and then the F9 camera opens in GROUP PLACEMENT mode. Aim at a walkable surface and position the group using:

| Control | Group movement |
| --- | --- |
| WASD / Mouse | Move the free camera and aim the group |
| Q / E | Rotate every actor in the crowd together |
| Mouse wheel | Tighten or widen crowd spacing |
| Z / X | Fine-tune group height (for stages/elevated surfaces) |
| Left mouse | Confirm group placement |
| Right mouse | Cancel movement and restore previous placements |

Crowd poses exclude `lean`. Each mood includes clapping and prefers `clap2`, with `clap` as the fallback.

On first placement, the script reads the matching emote definitions from **RPEmotes Reborn** and gives each member a different available code until the palette is exhausted, then reshuffles. Examples include `record`, `selfie`, `dance3`, `phone`, `clap`, `cheer`, `lean` and `wave`. Emotes are set to loop and attached props use the existing animation-support logic. Codes not present in your RPEmotes build are skipped instead of causing crashes. When RPEmotes is absent, only the built-in JSON emote definitions are available.

In **Placed groups**, use **Position** to move the whole crowd later, **New emotes** to reshuffle activities, or **Delete** (with confirmation) to remove all members of that crowd. Select the **Actors** tab to edit a crowd member individually with the normal green-crosshair/F9 editor; you can still give one individual a custom `/e` animation, weapon or behavior.

**Performance:** These are real GTA peds. A 30-person crowd can cost performance depending on vehicles, streaming, and other scripts. Start at 8–15 for busy servers. `Config.MaxActors = 85` is a protective ceiling, not a recommendation to use that many at once. Groups are **client-local** under the default `Config.NetworkedActors = false`, and are not saved after reconnect or restart. Do not advertise multi-user synchronization without testing the optional network mode.

**Limitations:** This is not a dancing crowd choreography engine. It assigns independent animation tasks and manages formation/position, not synchronized music or paired actor emotes. Some custom RPEmotes entries with staged effects, custom transitions, multiplayer sync, or unusual props may need additional handling. Rockstar Editor capture should be checked on your current FiveM/GTA build; this resource does not alter Rockstar Editor itself.

Validation: Lua syntax checks, a simulated Twelve-ped spawn/pose/delete flow, and browser UI checks passed. This is not a substitute for live FiveM testing.
