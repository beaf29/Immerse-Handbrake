-- Only parses RPEmotes' definition DATA. We never execute or load its Lua code.
local definitions = {}
local sourceLabel = 'Not detected'
local loaded = false

local function cleanCode(code)
  if type(code) ~= 'string' then return nil end
  code = code:lower():gsub('^%s+', ''):gsub('%s+$', '')
  code = code:gsub('^/e%s+', ''):gsub('^e%s+', '')
  if #code < 1 or #code > 70 or not code:match('^[%w_%-]+$') then return nil end
  return code
end

local function balancedEntry(text, openIndex)
  local depth, quote, escape, lineComment = 0, nil, false, false
  for i = openIndex, #text do
    local c = text:sub(i, i)
    local nextC = text:sub(i + 1, i + 1)
    if lineComment then
      if c == '\n' then lineComment = false end
    elseif quote then
      if escape then escape = false
      elseif c == '\\' then escape = true
      elseif c == quote then quote = nil end
    elseif c == '-' and nextC == '-' then
      lineComment = true
    elseif c == '"' or c == "'" then
      quote = c
    elseif c == '{' then
      depth = depth + 1
    elseif c == '}' then
      depth = depth - 1
      if depth == 0 then return text:sub(openIndex + 1, i - 1), i end
    end
  end
end

local function parsePlacement(raw)
  if not raw then return nil end
  local numbers = {}
  for part in raw:gmatch('[^,]+') do
    local n = tonumber(part:match('[-+]?%d*%.?%d+'))
    if n then numbers[#numbers + 1] = n end
  end
  if #numbers < 6 then return nil end
  return { numbers[1], numbers[2], numbers[3], numbers[4], numbers[5], numbers[6] }
end

local function parseEntry(body)
  -- Format: { "animation_dictionary", "animation_name", "Display name", AnimationOptions={...} }
  local first, second = body:match('^%s*["\']([^"\']+)["\']%s*,%s*["\']([^"\']+)["\']')
  if not first or not second then return nil end
  local info
  if first == 'Scenario' or first == 'MaleScenario' or first == 'FemaleScenario' then
    info = { kind = 'scenario', scenario = second }
  else
    info = { kind = 'anim', dict = first, clip = second,
      loop = body:match('EmoteLoop%s*=%s*true') ~= nil,
      moving = body:match('EmoteMoving%s*=%s*true') ~= nil }
    info.duration = tonumber(body:match('EmoteDuration%s*=%s*(%d+)')) or -1
    local prop = body:match('Prop%s*=%s*["\']([^"\']+)["\']')
    if prop then
      local placement = parsePlacement(body:match('PropPlacement%s*=%s*{(.-)}'))
      if placement then
        info.props = {{ model = prop, bone = tonumber(body:match('PropBone%s*=%s*(%d+)')) or 28422, placement = placement }}
      end
    end
    local secondProp = body:match('SecondProp%s*=%s*["\']([^"\']+)["\']')
    if secondProp then
      local placement = parsePlacement(body:match('SecondPropPlacement%s*=%s*{(.-)}'))
      if placement then
        info.props = info.props or {}
        info.props[#info.props + 1] = { model = secondProp, bone = tonumber(body:match('SecondPropBone%s*=%s*(%d+)')) or 28422, placement = placement }
      end
    end
  end
  return info
end

local function parseLuaDefinitions(contents)
  local count = 0
  local pos = 1
  while pos <= #contents do
    -- ["wave"] = { ... } records. Nested options are rejected unless they begin with two strings.
    local begin, ending, code = contents:find('%["([%w_%-]+)"%]%s*=%s*{', pos)
    if not begin then
      begin, ending, code = contents:find("%['([%w_%-]+)'%]%s*=%s*{", pos)
    end
    if not begin then break end
    local openIndex = contents:find('{', ending, true)
    if openIndex then
      local body, last = balancedEntry(contents, openIndex)
      if body then
        local info = parseEntry(body)
        if info and not definitions[code:lower()] then
          if not definitions[code:lower()] or info.override == true then
            definitions[code:lower()] = info
          end
          count = count + 1
        end
        pos = last + 1
      else
        pos = ending + 1
      end
    else
      pos = ending + 1
    end
  end
  return count
end

local function loadDefinitions()
  definitions = {}
  local sources = {}
  for _, resource in ipairs(Config.EmoteResources or {}) do
    local state = GetResourceState(resource)
    if state == 'started' or state == 'starting' then
      for _, filepath in ipairs(Config.EmoteFilePaths or {}) do
        local contents = LoadResourceFile(resource, filepath)
        if contents and #contents > 0 then
          local count = parseLuaDefinitions(contents)
          if count > 0 then sources[#sources + 1] = resource .. ':' .. filepath .. ' (' .. count .. ')' end
        end
      end
    end
  end
  local contents = LoadResourceFile(GetCurrentResourceName(), 'emotes.json')
  if contents then
    local ok, decoded = pcall(json.decode, contents)
    if ok and type(decoded) == 'table' then
      for code, info in pairs(decoded) do
        if type(code) == 'string' and type(info) == 'table' and
          (info.kind == 'anim' or info.kind == 'scenario') then
          if not definitions[code:lower()] or info.override == true then
            definitions[code:lower()] = info
          end
        end
      end
    end
  end
  sourceLabel = #sources > 0 and table.concat(sources, ', ') or 'Built-in JSON only (RPEmotes not found)'
  loaded = true
  local count = 0
  for _ in pairs(definitions) do count = count + 1 end
  print(('[immerse_actors] Loaded %s emote codes. Sources: %s'):format(count, sourceLabel))
end

CreateThread(function()
  Wait(1400)
  loadDefinitions()
end)

RegisterNetEvent('immerse_actors:requestEmote', function(requestId, code)
  local src = source
  if not loaded then loadDefinitions() end
  local normalized = cleanCode(code)
  if not normalized then
    TriggerClientEvent('immerse_actors:emoteResponse', src, requestId, nil, 'Enter a valid emote code.')
    return
  end
  local info = definitions[normalized]
  if not info then
    TriggerClientEvent('immerse_actors:emoteResponse', src, requestId, nil,
      ('"%s" was not found. Check RPEmotes folder in config.lua or emotes.json.'):format(normalized))
    return
  end
  TriggerClientEvent('immerse_actors:emoteResponse', src, requestId, info, normalized)
end)


-- Resolve an entire emote palette in one network round trip for Crowd Builder.
RegisterNetEvent('immerse_actors:requestCrowdEmotes',function(groupId,codes)
  local src=source
  if not loaded then loadDefinitions() end
  if type(codes)~='table' or #codes>40 or type(groupId)~='number' then return end
  local found={}
  for _,code in ipairs(codes) do
    local normalized=cleanCode(code)
    if normalized and definitions[normalized] then found[normalized]=definitions[normalized] end
  end
  TriggerClientEvent('immerse_actors:crowdEmotes',src,groupId,found)
end)

RegisterNetEvent('immerse_actors:requestStatus', function()
  local src = source
  if not loaded then loadDefinitions() end
  TriggerClientEvent('immerse_actors:status', src, sourceLabel)
end)

RegisterCommand('sceneactorsreload', function(src)
  -- Server console only; resource scripts are read on demand from the installed RPEmotes.
  if src ~= 0 then return end
  loadDefinitions()
end, false)
