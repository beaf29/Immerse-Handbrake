-- The server owns the parking-brake state. Only the current driver may change it.
-- State bags keep the vehicle's setting in sync for players who stream in later.
RegisterNetEvent('mp_handbrake:set', function(networkId, engaged)
    local playerId = source
    if type(networkId) ~= 'number' or type(engaged) ~= 'boolean' then return end
    if networkId < 1 or networkId > 65535 then return end

    local vehicle = NetworkGetEntityFromNetworkId(networkId)
    if vehicle == 0 or not DoesEntityExist(vehicle) or GetEntityType(vehicle) ~= 2 then return end

    local ped = GetPlayerPed(playerId)
    if ped == 0 or GetPedInVehicleSeat(vehicle, -1) ~= ped then return end

    Entity(vehicle).state:set('mpHandbrake', engaged, true)
end)
