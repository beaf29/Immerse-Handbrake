Config = {}

-- Spacebar: GTA's INPUT_VEH_HANDBRAKE (76).
Config.HandbrakeControl = 76

-- A newly spawned vehicle starts with the parking brake released.
Config.DefaultEngaged = false

-- Only engage near a stop (m/s). Approx. 4.5 mph.
Config.MaxEngageSpeed = 2.0

-- Press W or S to automatically release the handbrake while driving.
-- F is handled separately: exiting NEVER releases the handbrake.
Config.AutoReleaseOnDrive = true
Config.DriveInputThreshold = 0.24
Config.ExitGuardMs = 3500        -- protect state during vehicle exit animation
Config.ExitBrakeHoldMs = 1800    -- keep wheel brake applied during seat transition
Config.StateSyncGraceMs = 2000   -- don't let replication latency undo a quick toggle

-- Cars, pickups, vans, emergency and heavy vehicles. No bikes or aircraft.
Config.AllowedClasses = {
    [0] = true, [1] = true, [2] = true, [3] = true, [4] = true,
    [5] = true, [6] = true, [7] = true, [9] = true, [10] = true,
    [11] = true, [12] = true, [17] = true, [18] = true,
    [19] = true, [20] = true, [22] = true
}

-- v1.2 hill-roll tuning. Assistance runs ONLY while no driver is in a
-- supported car with its parking brake DISENGAGED. Other vehicles are left alone.
Config.RollWhenReleased = true
Config.RollSlopeThreshold = 0.035     -- ~2 degrees along the direction of travel
Config.RollGroundSampleDistance = 1.8 -- meters ahead/behind to read the road grade
Config.RollAssistFactor = 2.2        -- balances GTA's heavy parked-car friction
Config.RollMinAcceleration = 0.55    -- minimum downhill acceleration (m/s^2)
Config.RollMaxGrade = 0.45           -- ignore impossible cliff-like slopes
Config.MaxAssistedRollSpeed = 7.0    -- stop ADDING force after this speed (m/s)
Config.RollForceFadeStart = 4.5      -- begin gently tapering added force here
Config.RollLaunchAssistSpeed = 0.95 -- only near rest, help wheels break free
Config.RollMaxLaunchDelta = 0.15    -- max velocity nudge per tick (m/s)
Config.PhysicsIntervalMs = 50
Config.ScanIntervalMs = 850
Config.SimulationRange = 75.0

-- Your original engage/disengage clips (converted to MP3).
Config.SoundVolume = 0.70
