-- MP Handbrake | Standalone v1.2
-- SPACE toggles a wheel handbrake. F exits WITHOUT changing that state.
-- We never freeze, teleport, anchor, or overwrite a vehicle's velocity.

local activeVehicle = 0
local activeEngaged = false
local nearby = {}       -- nearby vehicles that have a replicated handbrake state
local pending = {}      -- protects very recent changes from state bag latency

local exitGuardVehicle = 0
local exitGuardUntil = 0
local recentlyExitedVehicle = 0
local recentlyExitedEngaged = false
local recentlyExitedUntil = 0

local function supported(vehicle)
    return vehicle ~= 0 and DoesEntityExist(vehicle)
        and Config.AllowedClasses[GetVehicleClass(vehicle)] == true
end

local function ownsPhysics(vehicle)
    return not NetworkGetEntityIsNetworked(vehicle)
        or NetworkHasControlOfEntity(vehicle)
end

local function playSound(engaged)
    SendNUIMessage({
        action = 'handbrakeSound',
        type = engaged and 'engage' or 'disengage',
        volume = Config.SoundVolume
    })
end

local function recordLocalState(vehicle, engaged)
    nearby[vehicle] = engaged
    pending[vehicle] = {
        value = engaged,
        expires = GetGameTimer() + Config.StateSyncGraceMs
    }
end

local function synchronize(vehicle, engaged)
    if NetworkGetEntityIsNetworked(vehicle) then
        local networkId = NetworkGetNetworkIdFromEntity(vehicle)
        if networkId ~= 0 then
            TriggerServerEvent('mp_handbrake:set', networkId, engaged)
            return
        end
    end
    -- This only affects a local (non-networked) vehicle.
    Entity(vehicle).state:set('mpHandbrake', engaged, false)
end

local function setBrake(vehicle, engaged, sound)
    if not supported(vehicle) then return end
    activeEngaged = engaged
    recordLocalState(vehicle, engaged)
    SetVehicleHandbrake(vehicle, engaged)
    synchronize(vehicle, engaged)
    if sound then playSound(engaged) end
end

local function readBrake(vehicle)
    local state = Entity(vehicle).state.mpHandbrake
    local recent = pending[vehicle]
    if recent then
        if state == recent.value then
            pending[vehicle] = nil
        elseif GetGameTimer() < recent.expires then
            return recent.value
        else
            pending[vehicle] = nil
        end
    end
    if type(state) == 'boolean' then return state end
    if nearby[vehicle] ~= nil then return nearby[vehicle] end
    return Config.DefaultEngaged
end

-- Parking brake controls. Keep SPACE intercepted so the stock GTA control
-- doesn't add a second, hold-to-brake input over the toggle.
CreateThread(function()
    while true do
        local ped = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(ped, false)
        local driver = supported(vehicle) and GetPedInVehicleSeat(vehicle, -1) == ped
        local now = GetGameTimer()

        if driver then
            if vehicle ~= activeVehicle then
                activeVehicle = vehicle
                activeEngaged = readBrake(vehicle)
                nearby[vehicle] = activeEngaged
                exitGuardVehicle = 0
                recentlyExitedVehicle = 0

                SetVehicleHandbrake(vehicle, activeEngaged)
                -- Register a new vehicle for parked, networked physics.
                if Entity(vehicle).state.mpHandbrake == nil then
                    recordLocalState(vehicle, activeEngaged)
                    synchronize(vehicle, activeEngaged)
                end
            end

            DisableControlAction(0, Config.HandbrakeControl, true)

            -- F is INPUT_VEH_EXIT (75). Latch the current state before GTA
            -- begins the door/exit animation. Exiting NEVER changes it.
            if IsControlJustPressed(0, 75) then
                exitGuardVehicle = vehicle
                exitGuardUntil = now + Config.ExitGuardMs
            end
            local leaving = exitGuardVehicle == vehicle and now < exitGuardUntil
            if not leaving then
                local wantsToDrive = Config.AutoReleaseOnDrive and activeEngaged and (
                    GetControlNormal(0, 71) > Config.DriveInputThreshold or
                    GetControlNormal(0, 72) > Config.DriveInputThreshold
                )

                if wantsToDrive then
                    setBrake(vehicle, false, true)
                elseif IsDisabledControlJustPressed(0, Config.HandbrakeControl) then
                    if activeEngaged then
                        setBrake(vehicle, false, true)
                    elseif GetEntitySpeed(vehicle) <= Config.MaxEngageSpeed then
                        setBrake(vehicle, true, true)
                    end
                end
            end

            -- Game logic can clear a vehicle's wheel brake during exit tasks.
            -- Reapply the chosen state every frame until the driver is out.
            SetVehicleHandbrake(vehicle, activeEngaged)
            Wait(0)
        else
            if activeVehicle ~= 0 then
                -- Preserve the brake across the transition out of the seat.
                recentlyExitedVehicle = activeVehicle
                recentlyExitedEngaged = activeEngaged
                recentlyExitedUntil = now + Config.ExitBrakeHoldMs
                activeVehicle = 0
                exitGuardVehicle = 0
            end

            if recentlyExitedVehicle ~= 0 then
                local old = recentlyExitedVehicle
                if now >= recentlyExitedUntil or not supported(old) then
                    recentlyExitedVehicle = 0
                else
                    local occupant = GetPedInVehicleSeat(old, -1)
                    if (occupant == 0 or occupant == ped) and ownsPhysics(old) then
                        SetVehicleHandbrake(old, recentlyExitedEngaged)
                    end
                end
            end

            -- The short, frame-rate exit handoff prevents a transient release.
            Wait(recentlyExitedVehicle ~= 0 and 0 or 200)
        end
    end
end)

-- An infrequent scan discovers only cars with this script's saved state.
-- We don't modify unrelated traffic or parked NPC vehicles.
CreateThread(function()
    while true do
        Wait(Config.ScanIntervalMs)
        local playerCoords = GetEntityCoords(PlayerPedId())
        local maxDistSq = Config.SimulationRange * Config.SimulationRange
        local nextNearby = {}
        local now = GetGameTimer()

        for _, vehicle in ipairs(GetGamePool('CVehicle')) do
            if supported(vehicle) then
                local coords = GetEntityCoords(vehicle)
                local x = coords.x - playerCoords.x
                local y = coords.y - playerCoords.y
                local z = coords.z - playerCoords.z
                if x*x + y*y + z*z <= maxDistSq then
                    local saved = Entity(vehicle).state.mpHandbrake
                    local recent = pending[vehicle]

                    -- Give state bags a moment to catch up after a quick
                    -- SPACE then F. Otherwise a stale bag can undo the exit.
                    if recent and now >= recent.expires then
                        pending[vehicle] = nil
                        recent = nil
                    end
                    if recent and saved == recent.value then
                        pending[vehicle] = nil
                        recent = nil
                    end

                    if recent then
                        nextNearby[vehicle] = recent.value
                    elseif type(saved) == 'boolean' then
                        nextNearby[vehicle] = saved
                    elseif vehicle == activeVehicle then
                        nextNearby[vehicle] = activeEngaged
                    end
                end
            end
        end
        nearby = nextNearby

        -- Remove entries for streamed-out/despawned vehicles.
        for vehicle in pairs(pending) do
            if not nextNearby[vehicle] and vehicle ~= activeVehicle then
                pending[vehicle] = nil
            end
        end
    end
end)

-- Determine road grade under the wheels, NOT just the visual pitch of a
-- bouncing/suspension-compressed car. Positive grade = car faces downhill.
local function getWheelAxisGrade(vehicle, coords, fx, fy)
    local sample = Config.RollGroundSampleDistance
    local probeZ = coords.z + 4.0
    local foundFront, frontZ = GetGroundZFor_3dCoord(
        coords.x + fx * sample, coords.y + fy * sample, probeZ, false
    )
    local foundBack, backZ = GetGroundZFor_3dCoord(
        coords.x - fx * sample, coords.y - fy * sample, probeZ, false
    )

    -- Ignore geometry far below bridges/parking structures and weird curb
    -- samples. Both wheel samples must describe roughly the car's road.
    if foundFront and foundBack
        and math.abs(frontZ - coords.z) < 3.5
        and math.abs(backZ - coords.z) < 3.5 then
        return (backZ - frontZ) / (2.0 * sample)
    end

    -- Where ground-height probes do not resolve (some MLOs/roads), use the
    -- ground's surface normal as a fallback.
    local found, groundZ, normal = GetGroundZAndNormalFor_3dCoord(
        coords.x, coords.y, probeZ
    )
    if found and normal and normal.z > 0.65
        and math.abs(coords.z - groundZ) < 3.5 then
        return (normal.x * fx + normal.y * fy) / normal.z
    end

    return nil
end

-- GTA often holds an unattended car almost stationary, even with its wheel
-- handbrake off. v1.1 applied too little force, and stopped helping as soon
-- as speed reached ~1.6 m/s. v1.2 allows gravity-like acceleration to build
-- speed and provides a tiny launch nudge ONLY at near-zero speed.
--
-- Never freeze, warp, anchor or rotate the vehicle. The roll acts in the
-- vehicle's own forward/back direction, so collisions remain physical.
local function assistSlopeRoll(vehicle, dt)
    if not Config.RollWhenReleased then return end
    if not IsVehicleOnAllWheels(vehicle) or IsEntityInAir(vehicle) then return end

    local speed = GetEntitySpeed(vehicle)
    if speed >= Config.MaxAssistedRollSpeed then return end

    local forward = GetEntityForwardVector(vehicle)
    local horizontal = math.sqrt(forward.x * forward.x + forward.y * forward.y)
    if horizontal < 0.65 then return end
    local fx, fy = forward.x / horizontal, forward.y / horizontal

    local coords = GetEntityCoords(vehicle)
    local grade = getWheelAxisGrade(vehicle, coords, fx, fy)
    if not grade or math.abs(grade) <= Config.RollSlopeThreshold then return end

    local direction = grade > 0 and 1.0 or -1.0
    local absGrade = math.min(math.abs(grade), Config.RollMaxGrade)
    local acceleration = math.max(
        Config.RollMinAcceleration,
        9.81 * absGrade * Config.RollAssistFactor
    )

    -- Gradual fade-out rather than a hard cutoff while the car is rolling.
    if speed > Config.RollForceFadeStart then
        local fraction = (Config.MaxAssistedRollSpeed - speed) /
            (Config.MaxAssistedRollSpeed - Config.RollForceFadeStart)
        acceleration = acceleration * math.max(0.0, math.min(1.0, fraction))
    end

    local vx = fx * direction
    local vy = fy * direction
    local velocity = GetEntityVelocity(vehicle)
    local longitudinalSpeed = (velocity.x * fx + velocity.y * fy) * direction
    local lateral = velocity.x * (-fy) + velocity.y * fx

    -- Do not fight a collision/sliding car or undo actual backwards motion.
    -- A car rolling uphill will naturally slow and turn around on a hill.
    if math.abs(lateral) > 0.9 then return end

    -- Force type 1 is an impulse. With mass scaling, a * dt is a velocity
    -- change, not an arbitrary fixed impulse. Always apply at the center of
    -- mass, so this cannot flip the car from an off-center force.
    if dt > 0.0 then
        ApplyForceToEntity(
            vehicle, 1,
            vx * acceleration * dt, vy * acceleration * dt, 0.0,
            0.0, 0.0, 0.0,
            0, false, false, true, false, true
        )
    end

    -- GTA's parked-vehicle brake/tyre resistance sometimes completely eats
    -- very small impulses from a standstill. Seed a LOW, physically sized
    -- forward/back velocity only at walking pace so the tyres can start to
    -- turn. Preserve vertical/lateral velocity; never reset collision speed.
    if speed < Config.RollLaunchAssistSpeed
        and longitudinalSpeed >= -0.12
        and longitudinalSpeed < Config.RollLaunchAssistSpeed
        and dt > 0.0 then
        local delta = math.min(acceleration * dt, Config.RollMaxLaunchDelta)
        local room = Config.RollLaunchAssistSpeed - longitudinalSpeed
        delta = math.min(delta, room)
        if delta > 0.0 then
            SetEntityVelocity(
                vehicle,
                velocity.x + vx * delta,
                velocity.y + vy * delta,
                velocity.z
            )
        end
    end
end

-- Maintain the saved wheel-brake state after occupants leave.
-- Only the physics owner acts on a vehicle, avoiding multiplayer jitter.
CreateThread(function()
    local previousTick = GetGameTimer()
    while true do
        Wait(Config.PhysicsIntervalMs)
        local now = GetGameTimer()
        local dt = math.min(math.max((now - previousTick) / 1000.0, 0.0), 0.20)
        previousTick = now

        local pedCoords = GetEntityCoords(PlayerPedId())
        local maxDistSq = Config.SimulationRange * Config.SimulationRange
        for vehicle, engaged in pairs(nearby) do
            if supported(vehicle) and ownsPhysics(vehicle) then
                local coords = GetEntityCoords(vehicle)
                local x = coords.x - pedCoords.x
                local y = coords.y - pedCoords.y
                local z = coords.z - pedCoords.z
                local occupant = GetPedInVehicleSeat(vehicle, -1)
                if x*x + y*y + z*z <= maxDistSq and occupant == 0 then
                    SetVehicleHandbrake(vehicle, engaged)
                    if not engaged and dt > 0.0 then
                        -- GTA can retain a regular brake after its exit task.
                        -- Clear it only for empty, released cars.
                        SetVehicleBrake(vehicle, false)
                        assistSlopeRoll(vehicle, dt)
                    end
                end
            end
        end
    end
end)

AddEventHandler('onClientResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    -- Don't leave a native wheel brake latched when uninstalling the resource.
    for vehicle in pairs(nearby) do
        if DoesEntityExist(vehicle) and ownsPhysics(vehicle) then
            SetVehicleHandbrake(vehicle, false)
        end
    end
end)
