'use strict';

const tracks = {
  engage: new Audio('sounds/engage.mp3'),
  disengage: new Audio('sounds/disengage.mp3')
};

Object.values(tracks).forEach((sound) => {
  sound.preload = 'auto';
  sound.load();
});

window.addEventListener('message', (event) => {
  const data = event.data;
  if (!data || data.action !== 'handbrakeSound') return;
  const sound = tracks[data.type];
  if (!sound) return;
  sound.pause();
  sound.currentTime = 0;
  const requestedVolume = Number(data.volume);
  sound.volume = Number.isFinite(requestedVolume)
    ? Math.max(0, Math.min(1, requestedVolume))
    : 0.7;
  sound.play().catch(() => { /* NUI not ready / audio unavailable */ });
});
