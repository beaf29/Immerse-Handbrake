MP HANDBRAKE v1.2 | Immerse Solutions
==================================

A standalone FiveM handbrake resource. No ox_lib, vMenu, ESX or QBCore needed.

INSTALLATION
1. Remove/replace your OLD MP_Handbrake folder with this one.
   Do not run two handbrake resources at the same time.
2. Put MP_Handbrake in your server's resources folder.
3. Add: ensure MP_Handbrake
4. Restart the resource/server.

CONTROLS AND BEHAVIOR
- SPACE: toggle engaged/disengaged; plays your matching sound.
- F: leave the vehicle WITHOUT disengaging the handbrake.
- W/S: automatically disengage while YOU are driving and trying to move.
- With the handbrake ON, exiting leaves it ON, even during door animations.
- With the handbrake OFF, an unattended vehicle can roll on a slope.
- A parked vehicle is never frozen. Other vehicles can ram, push or tip it.
- No menus, HUD, required permissions, or chat messages.

v1.2 PHYSICS FIX
- A steep hill now produces a stronger, gradual forward/backward roll.
- Uses front/back road-height samples with a ground-normal fallback. Grade
  is measured along the car's wheels (not sideways along a cross slope).
- Clears lingering regular wheel brake on unoccupied released cars.
- Fixes weak v1.1 impulses and their premature ~1.6 m/s stop.
- Gives very slow cars a small, limited velocity nudge to overcome GTA's
  parked-tyre resistance. It does not overwrite meaningful collision motion.
- Continues smooth physical assistance until natural momentum takes over.
- No freeze, teleport, forced forward speed or changes to handling.meta.
- Engaged cars remain pushable/tippable by other vehicles.
- SPACE, F exit persistence, W/S auto-release, replication and both sound
  clips remain the same as v1.1.

CALIBRATION (config.lua)
- RollSlopeThreshold (0.035): minimum slope along wheels; smaller rolls on
  gentler slopes. On a flat road the car should remain still.
- RollAssistFactor (2.2): higher = faster downhill gain; for very heavy
  custom cars try 2.5 or 2.8. For light cars try 1.7.
- RollMinAcceleration (0.55): helps shallow hills overcome static friction.
- RollLaunchAssistSpeed (0.95): short start-off boost only at walking pace.
- MaxAssistedRollSpeed (7.0): maximum speed at which script adds downhill
  acceleration; NOT a forced speed cap on the car.
- PhysicsIntervalMs (50): change only if needed for server performance.

TEST PLAN
1. Engage SPACE, exit F. Vehicle must stay braked; no automatic release.
2. Reenter, hold W/S. Brake must auto-disengage; correct sound plays.
3. Face a car uphill on a clear, steep street, release SPACE and exit F.
   It should move BACKWARDS downhill and build speed smoothly.
4. Face the car downhill and repeat. It should roll FORWARDS downhill.
5. Repeat on level ground; no significant self-propelled movement.
6. Ram an engaged car; it must remain fully physical, not anchored.
7. Check with 2 clients and heavy custom vehicles; handling varies.

YOUR SOUNDS
html/sounds/engage.mp3    <- videoplayback (mp3cut.net).m4a
html/sounds/disengage.mp3 <- disengage.m4a

QUICK TESTS
1. Stop on level ground, hit SPACE, then F. Brake stays engaged.
2. Re-enter the same car; it is still engaged. Press W: it releases.
3. Engage then leave immediately (SPACE -> F): remains engaged.
4. On a clear hill, leave it disengaged: car starts a gentle downhill roll.
5. Face across the hill: no artificial sideways acceleration.
6. Ram into parked engaged vehicle: vehicle remains a physical object.
7. Check two-player sync with OneSync, including streaming in/out.

NOTE
State is stored per current vehicle entity, not across deletions/server
restarts. Actual movement depends on GTA vehicle handling; collision and
rolling physics cannot be guaranteed on every custom vehicle without a
live in-game test.
