fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author "Immerse Solutions"
description 'MP Handbrake | Spacebar toggle, physical parking brake and slope rolling'
version '1.0.0'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

ui_page 'html/index.html'
files {
    'html/index.html',
    'html/app.js',
    'html/sounds/engage.mp3',
    'html/sounds/disengage.mp3'
}
